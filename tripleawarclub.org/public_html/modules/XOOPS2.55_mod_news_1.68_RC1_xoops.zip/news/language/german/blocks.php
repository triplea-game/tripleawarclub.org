<?php
// $Id$
define("_MB_NEWS_NOTYET","Es gibt heute noch keinen Leitartikel.");
define("_MB_NEWS_TMRSI","Der heute meist gelesene Artikel ist:");
define("_MB_NEWS_ORDER","Sortiert nach");
define("_MB_NEWS_DATE","Veröffentlichungsdatum");
define("_MB_NEWS_HITS","Anzahl der Aufrufe");
define("_MB_NEWS_DISP","Anzeigen");
define("_MB_NEWS_ARTCLS","Artikel");
define("_MB_NEWS_CHARS","Löschen des Titels: ");
define("_MB_NEWS_LENGTH"," Zeichen");
define("_MB_TITLE", "Titel");
define("_MB_POSTED", "Geschrieben");
define("_MB_POSTER", "Autor");
define("_MB_ACTION", "Aktion");
define("_MB_TOPIC", "Thema");
define("_MB_DELETE", "Löschen");
define("_MB_NEWS_RESTRICTTOPICS", "Eingeschränkte Themen für User sichtbar?");
define("_MB_NEWS_TEASER", "Länge für Anreißer (0 für keinen)");
define("_MB_NEWS_SPOTLIGHT", "Aktivieren der Spotlight Eigenschaft");
define("_MB_NEWS_FIRST", "--Erster Eintrag--");
define("_MB_NEWS_IMAGE", "Bild für Spotlight");
define("_MB_SPOTLIGHT_TOPIC", "Themenauswahl die verwendet werden");
define("_MB_SPOTLIGHT_ALL_TOPICS", "Alle Themen");
define("_MB_NEWS_SPOTLIGHT_ARTICLE", "Artikel auswählen:");
define("_MB_READMORE","mehr...");
define("_MB_NEWS_RATE","Bewertung");
define("_MB_NEWS_SHOW_NEWS_COUNT","Artikelzähler anzeigen ?");
define("_MB_NEWS_SPOTLIGHT_TITLE", "Spotlight");
define("_MB_NEWS_VIEW_TYPE1", "Klassisch");
define("_MB_NEWS_VIEW_TYPE2", "In Tabs");
define("_MB_NEWS_TAB_COLOR1", "Farbe der Linie die sich unter den Tabs befindet");
define("_MB_NEWS_TAB_COLOR2", "Hintergrundfarbe des Tab Inhalts");
define("_MB_NEWS_TAB_COLOR3", "Aktive Tabfarbe");
define("_MB_NEWS_TAB_COLOR4", "Farbe der nicht aktiven Tabs");
define("_MB_NEWS_TAB_COLOR5", "Kopfbereich hover Farbe");
define("_MB_NEWS_WHAT_PUBLISH", "Was soll im Spotlight <br />angezeigt werde?");
define("_MB_NEWS_RECENT_NEWS", "Aktuellste Artikel (Liste unten nicht benutzen)");
define("_MB_NEWS_RECENT_SPECIFIC", "Artikel aus unten aufgeführter Liste");
define("_MB_NEWS_DEFAULT_COLORS", "Nichts eintragen um die Standardfarben zu nutzen.");

// Added in version 1.50
define("_MB_NEWS_CAL_YEAR", "Jahr");
define("_MB_NEWS_CAL_MONTH", "Monat");
define("_MB_NEWS_STARTING_DATE", "Beginn");
define("_MB_NEWS_ENDING_DATE", "Ende");
define("_MB_NEWS_UNTIL_TODAY", "Bis heute");
define("_MB_NEWS_RECENT_FIRST", "Neueste zuerst");
define("_MB_NEWS_OLDER_FIRST", "Älteste zuerst");
?>