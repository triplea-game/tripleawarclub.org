<?php
$newslettertemplate=<<<contentend
Titel: %title%
Thema: %topic_title%
Geschrieben von: %publisher%
Veröffentlicht am: %published%
Bewertung: %rating%
Gelesen: %reads%

Inhalt:
%hometext%

Mehr lesen: %link%
 ----------------------------------------------------------------------------

contentend;
?>