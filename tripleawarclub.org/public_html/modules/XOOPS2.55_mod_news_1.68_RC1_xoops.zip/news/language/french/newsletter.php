<?php
$newslettertemplate=<<<contentend

Titre : %title%
Sujet : %topic_title%
Auteur : %publisher%
Date de Publication : %published%
Note : %rating%
Nombre de lectures : %reads%

Contenu :
%hometext%

En savoir plus : %link%
 ----------------------------------------------------------------------------

contentend;

/**
 * @translation     Communauté Francophone des Utilisateurs de Xoops
 * @specification   _LANGCODE: fr
 * @specification   _CHARSET: UTF-8 sans Bom
 *
 * @version         $Id $
**/
?>
