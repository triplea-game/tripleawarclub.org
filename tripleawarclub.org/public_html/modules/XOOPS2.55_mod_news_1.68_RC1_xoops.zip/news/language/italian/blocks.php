<?php
// $Id$
define("_MB_NEWS_NOTYET", "Non c&#39;è una storia più grande di oggi, ancora.");
define("_MB_NEWS_TMRSI", "Articolo più letto del Giorno è:");
define("_MB_NEWS_ORDER", "Ordina per");
define("_MB_NEWS_DATE", "Data di pubblicazione");
define("_MB_NEWS_HITS", "Numero di riscontri");
define("_MB_NEWS_DISP", "display, schermo");
define("_MB_NEWS_ARTCLS", "articoli");
define("_MB_NEWS_CHARS", "Lunghezza del titolo");
define("_MB_NEWS_LENGTH", "caratteri");
define("_MB_TITLE", "Titolo");
define("_MB_POSTED", "Inviato");
define("_MB_POSTER", "Autore");
define("_MB_ACTION", "azione");
define("_MB_TOPIC", "Argomento");
define("_MB_DELETE", "Elimina");
define("_MB_NEWS_RESTRICTTOPICS", "Limitare temi visualizzabili dall&#39;utente?");
define("_MB_NEWS_TEASER", "Mostra Lunghezza Teaser (0 per nessun occhiolino)");
define("_MB_NEWS_SPOTLIGHT", "Abilita funzionalità Spotlight");
define("_MB_NEWS_FIRST", "- Prima voce -");
define("_MB_NEWS_IMAGE", "Immagine per Spotlight");
define("_MB_SPOTLIGHT_TOPIC", "Seleziona argomento (s) da utilizzare");
define("_MB_SPOTLIGHT_ALL_TOPICS", "Tutti gli argomenti");
define("_MB_NEWS_SPOTLIGHT_ARTICLE", "Seleziona un articolo:");
define("_MB_READMORE", "leggere successivo...");
define("_MB_NEWS_RATE", "classificazione");
define("_MB_NEWS_SHOW_NEWS_COUNT", "Mostra contare notizia?");
define("_MB_NEWS_SPOTLIGHT_TITLE", "messi in evidenza");
define("_MB_NEWS_VIEW_TYPE1", "Classica");
define("_MB_NEWS_VIEW_TYPE2", "Con schede");
define("_MB_NEWS_TAB_COLOR1", "Colore della linea di sintesi (questa è la linea appena sotto il nome della scheda)");
define("_MB_NEWS_TAB_COLOR2", "Colore di sfondo del contenuto della scheda");
define("_MB_NEWS_TAB_COLOR3", "Intestazione scheda corrente a colori");
define("_MB_NEWS_TAB_COLOR4", "Colore di intestazione per le schede non selezionate");
define("_MB_NEWS_TAB_COLOR5", "Intestazione di colore hover");
define("_MB_NEWS_WHAT_PUBLISH", "Che cosa si desidera pubblicare <br /> sotto i riflettori?");
define("_MB_NEWS_RECENT_NEWS", "Notizie recenti (non utilizzare la lista qui sotto)");
define("_MB_NEWS_RECENT_SPECIFIC", "Una notizia specifica (vedi sotto)");
define("_MB_NEWS_DEFAULT_COLORS", "Lasciare la zona di vuoto per utilizzare i colori di default");

// Added in version 1.50
define("_MB_NEWS_CAL_YEAR", "Anno");
define("_MB_NEWS_CAL_MONTH", "Mese");
define("_MB_NEWS_STARTING_DATE", "Data di inizio");
define("_MB_NEWS_ENDING_DATE", "Data fine");
define("_MB_NEWS_UNTIL_TODAY", "o fino ad oggi");
define("_MB_NEWS_RECENT_FIRST", "Più recente");
define("_MB_NEWS_OLDER_FIRST", "Vecchi prima");
?><?php

// Translation done by XTransam & admin (info@txmodxoops.org)
// XTransam 1.2 is written by Chronolabs Co-op & The XOOPS Project - File Dumped on 2011-12-16 09:38

?>