<?php
$newslettertemplate=<<<contentend
Title : %title%
Topic : %topic_title%
Publisher : %publisher%
Publish date : %published%
Rating : %rating%
Reads : %reads%

Content :
%hometext%

Read More : %link%
 ----------------------------------------------------------------------------

contentend;
?>
<?php

// Translation done by XTransam & admin (info@txmodxoops.org)
// XTransam 1.2 is written by Chronolabs Co-op & The XOOPS Project - File Dumped on 2011-12-16 09:38

?>