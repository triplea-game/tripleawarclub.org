<?php
include_once '../../mainfile.php';
include_once XOOPS_ROOT_PATH.'/include/notification_update.php';
?>