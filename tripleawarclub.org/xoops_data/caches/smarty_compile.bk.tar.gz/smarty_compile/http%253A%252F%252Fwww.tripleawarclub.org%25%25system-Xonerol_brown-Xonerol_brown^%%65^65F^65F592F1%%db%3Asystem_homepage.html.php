<?php /* Smarty version 2.6.26, created on 2010-09-07 20:00:05
         compiled from db:system_homepage.html */ ?>
