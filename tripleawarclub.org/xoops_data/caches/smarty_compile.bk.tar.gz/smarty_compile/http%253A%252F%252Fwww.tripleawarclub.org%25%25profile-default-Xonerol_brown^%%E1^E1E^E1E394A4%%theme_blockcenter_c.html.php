<?php /* Smarty version 2.6.26, created on 2015-06-05 09:52:42
         compiled from default/theme_blockcenter_c.html */ ?>
<div style="padding: 5px;">
    <fieldset>
        <?php if ($this->_tpl_vars['block']['title']): ?>
            <legend class="blockTitle"><?php echo $this->_tpl_vars['block']['title']; ?>
</legend>
        <?php endif; ?>
        <div class="blockContent"><?php echo $this->_tpl_vars['block']['content']; ?>
</div>
    </fieldset>
</div>