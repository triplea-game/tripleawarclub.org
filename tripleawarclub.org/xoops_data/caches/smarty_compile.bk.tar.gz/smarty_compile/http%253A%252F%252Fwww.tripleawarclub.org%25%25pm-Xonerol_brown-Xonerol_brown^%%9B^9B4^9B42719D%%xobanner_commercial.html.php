<?php /* Smarty version 2.6.26, created on 2010-09-07 23:35:44
         compiled from Xonerol_brown/xotpl/xobanner_commercial.html */ ?>
<div id="xo-banner">
  <div id="xo-banner_inner">
  <!-- Site title and slogan -->
    <div id="xo-site-title">
      <!--<h1><span>TripleA War Club</span></h1>
      <h2>the Online TripleA community</h2>-->
    </div>
	<!-- Site Menu -->
<?php $this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['theme_name'])."/globalnav.html", 'smarty_include_vars' => array()));
 ?>
  </div>
</div>