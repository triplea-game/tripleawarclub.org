<?php /* Smarty version 2.6.26, created on 2010-09-19 19:59:35
         compiled from /var/www/vhosts/tripleawarclub.org/public_html/modules/system/class/gui/oxygen/theme.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->_tpl_vars['xoops_langcode']; ?>
" lang="<?php echo $this->_tpl_vars['xoops_langcode']; ?>
">
<head>
	<?php $this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['theme_tpl'])."/xo_metas.html", 'smarty_include_vars' => array()));
 ?>
	<?php $this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['theme_tpl'])."/xo_scripts.html", 'smarty_include_vars' => array()));
 ?>  
</head>
<body id="<?php echo $this->_tpl_vars['xoops_dirname']; ?>
" class="<?php echo $this->_tpl_vars['xoops_langcode']; ?>
">
    <?php $this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['theme_tpl'])."/xo_navbar.html", 'smarty_include_vars' => array()));
 ?>
    <?php $this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['theme_tpl'])."/xo_menu.html", 'smarty_include_vars' => array()));
 ?>
    <?php $this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['theme_tpl'])."/xo_toolbar.html", 'smarty_include_vars' => array()));
 ?>
    <?php $this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['theme_tpl'])."/xo_page.html", 'smarty_include_vars' => array()));
 ?>
	<?php $this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['theme_tpl'])."/xo_footer.html", 'smarty_include_vars' => array()));
 ?>
</body>
</html>