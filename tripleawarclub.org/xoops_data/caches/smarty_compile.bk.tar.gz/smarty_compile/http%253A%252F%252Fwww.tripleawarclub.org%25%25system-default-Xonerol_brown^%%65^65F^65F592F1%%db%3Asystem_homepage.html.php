<?php /* Smarty version 2.6.26, created on 2015-06-05 09:52:30
         compiled from db:system_homepage.html */ ?>
