<?php /* Smarty version 2.6.26, created on 2015-06-05 09:53:16
         compiled from default/theme_blockleft.html */ ?>
<?php if ($this->_tpl_vars['block']['title']): ?>
    <div class="blockTitle"><?php echo $this->_tpl_vars['block']['title']; ?>
</div>
<?php endif; ?>
<div class="blockContent"><?php echo $this->_tpl_vars['block']['content']; ?>
</div>