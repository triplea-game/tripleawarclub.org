<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:list/multimenu_list_select.html */ ?>
<br />
<div class="head"><?php echo $this->_tpl_vars['other']; ?>
 <?php echo $this->_tpl_vars['item']; ?>
 :
  <?php if ($this->_tpl_vars['count_list'] >= 8): ?></div><?php endif; ?>
  <select size="<?php if ($this->_tpl_vars['count_list'] >= 8): ?>5<?php endif; ?>"
          name="select"
          onchange="location=this.options[this.selectedIndex].value">

   <?php $_from = $this->_tpl_vars['items_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
           <option value="<?php echo $this->_tpl_vars['item']['urw']; ?>
"<?php if ($this->_tpl_vars['item']['id'] == $this->_tpl_vars['id']): ?> selected<?php endif; ?>><?php echo $this->_tpl_vars['item']['title']; ?>
</option>
   <?php endforeach; endif; unset($_from); ?>

  </select>
  <?php if ($this->_tpl_vars['count_list'] < 8): ?></div><?php endif; ?>