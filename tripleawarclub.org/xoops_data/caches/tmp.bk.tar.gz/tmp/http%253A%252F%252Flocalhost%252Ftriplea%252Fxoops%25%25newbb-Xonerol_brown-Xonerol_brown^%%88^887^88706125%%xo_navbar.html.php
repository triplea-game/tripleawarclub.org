<?php /* Smarty version 2.6.26, created on 2010-05-13 11:52:49
         compiled from /var/www/triplea/xoops/modules/system/class/gui/oxygen/xotpl/xo_navbar.html */ ?>
<div id="logoHead">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td>
                <a id="main_logo" class="tooltip" href="<?php echo 'http://localhost/triplea/xoops/admin.php'; ?>" title="<?php echo @_MD_OXYGEN_ADMINISTRATION; ?>
"></a>
            </td>
            <td id="headnav" class="other">
                <a class="tooltip" href="<?php echo 'http://localhost/triplea/xoops/'; ?>" title="<?php echo @_YOURHOME; ?>
"><img src="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/img/home.png'; ?>" alt="<?php echo @_YOURHOME; ?>
" /></a>
                <a class="tooltip" href="<?php echo 'http://localhost/triplea/xoops/user.php?op=logout'; ?>" title="<?php echo @_LOGOUT; ?>
"><img src="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/img/logout.png'; ?>" alt="<?php echo @_LOGOUT; ?>
" /></a>
            </td>
        </tr>
    </table>
</div>