<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:include/multimenu_dyn_horizontal.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'addslashes', 'db:include/multimenu_dyn_horizontal.html', 14, false),)), $this); ?>
<!-- Start multiMenu <?php echo $this->_tpl_vars['menu']; ?>
 -->

<!--[if gte IE 5.5]>
<iframe id="dropmenuiframe<?php echo $this->_tpl_vars['menu']; ?>
" src="" style="z-index:99;display:none;position:absolute;"></iframe>
<![endif]-->

<script language="JavaScript" type="text/javascript">
<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
<?php if ($this->_tpl_vars['item']['link_status'] == top || $this->_tpl_vars['item']['link_status'] == link): ?>
<?php $this->assign('mainlink_num', $this->_tpl_vars['item']['id']); ?>
          var menu_<?php echo $this->_tpl_vars['mainlink_num']; ?>
=new Array();
          <?php $this->assign('count', 0); ?>
<?php elseif ($this->_tpl_vars['item']['link_status'] == sublink): ?>
          menu_<?php echo $this->_tpl_vars['mainlink_num']; ?>
[<?php echo $this->_tpl_vars['count']; ?>
]='<a href="<?php echo $this->_tpl_vars['item']['link']; ?>
"<?php echo $this->_tpl_vars['item']['target']; ?>
<?php if ($this->_tpl_vars['item']['css']): ?> style="<?php echo $this->_tpl_vars['item']['css']; ?>
"<?php endif; ?>><?php if ($this->_tpl_vars['item']['image']): ?><img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"<?php if ($this->_tpl_vars['image_width']): ?><?php echo $this->_tpl_vars['image_width']; ?>
<?php endif; ?><?php if ($this->_tpl_vars['image_height']): ?> width="<?php echo $this->_tpl_vars['image_height']; ?>
"<?php endif; ?> align="absmiddle" /><?php endif; ?><?php echo ((is_array($_tmp=$this->_tpl_vars['item']['title'])) ? $this->_run_mod_handler('addslashes', true, $_tmp) : addslashes($_tmp)); ?>
</a>';
          <?php $this->assign('count', $this->_tpl_vars['count']+1); ?>
<?php endif; ?>
<?php endforeach; endif; unset($_from); ?>
</script>

<script language="JavaScript"
        type="text/javascript" 
        src="<?php echo $this->_tpl_vars['xoops_url']; ?>
<?php echo $this->_tpl_vars['script_link']; ?>
">
        </script>


<!-- Render Sublink datas -->
<div id="navcontainer">
<nobr>
  <ul>
  <?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
  <?php if ($this->_tpl_vars['item']['link_status'] == top || $this->_tpl_vars['item']['link_status'] == link): ?>
  		<li class="multimenu">
  		<a title="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"
  		<?php if ($this->_tpl_vars['item']['link']): ?><?php echo $this->_tpl_vars['item']['target']; ?>
 
                href="<?php echo $this->_tpl_vars['item']['link']; ?>
"<?php if ($this->_tpl_vars['item']['css']): ?> style="<?php echo $this->_tpl_vars['item']['css']; ?>
"<?php endif; ?><?php else: ?>style="cursor:pointer;" onClick="return clickreturnvalue_<?php echo $this->_tpl_vars['menu']; ?>
();"<?php endif; ?>
                <?php if ($this->_tpl_vars['item']['has_sub']): ?>onMouseover="dropdownmenu_<?php echo $this->_tpl_vars['menu']; ?>
(this, event, menu_<?php echo $this->_tpl_vars['item']['id']; ?>
, menuwidth_<?php echo $this->_tpl_vars['menu']; ?>
);"
  		onMouseout="delayhidemenu_<?php echo $this->_tpl_vars['menu']; ?>
();"<?php endif; ?>>
          <?php if ($this->_tpl_vars['item']['link_status'] == top || $this->_tpl_vars['item']['link_status'] == link): ?>
  		<?php if ($this->_tpl_vars['item']['has_sub']): ?><img src="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/multimenu/templates/include/multimenu_dyn_horizontal/arrow_down.gif" alt="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
" /><?php endif; ?>
  		<?php if ($this->_tpl_vars['item']['image']): ?><img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"<?php if ($this->_tpl_vars['image_width']): ?><?php echo $this->_tpl_vars['image_width']; ?>
<?php endif; ?><?php if ($this->_tpl_vars['image_height']): ?> width="<?php echo $this->_tpl_vars['image_height']; ?>
"<?php endif; ?> align="absmiddle" /><?php endif; ?>
  	<?php else: ?>
  		<li class="multimenu">
  		<a title="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"
  		<?php if ($this->_tpl_vars['item']['link']): ?><?php echo $this->_tpl_vars['item']['target']; ?>

                     href="<?php echo $this->_tpl_vars['item']['link']; ?>
"<?php endif; ?>
                <?php if ($this->_tpl_vars['item']['css']): ?>style="<?php echo $this->_tpl_vars['item']['css']; ?>
"<?php endif; ?>>
  	<?php endif; ?> <?php if ($this->_tpl_vars['item']['image']): ?><img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"<?php if ($this->_tpl_vars['image_width']): ?><?php echo $this->_tpl_vars['image_width']; ?>
<?php endif; ?><?php if ($this->_tpl_vars['image_height']): ?> width="<?php echo $this->_tpl_vars['image_height']; ?>
"<?php endif; ?> align="absmiddle" /><?php endif; ?>
  		<?php echo $this->_tpl_vars['item']['title']; ?>

  		</a>
  		</li>
   <?php endif; ?>
  <?php endforeach; endif; unset($_from); ?>
  </ul>
  </nobr>
</div>