<?php /* Smarty version 2.6.26, created on 2010-05-21 19:46:14
         compiled from db:system_block_dummy.html */ ?>
<?php echo $this->_tpl_vars['block']['content']; ?>