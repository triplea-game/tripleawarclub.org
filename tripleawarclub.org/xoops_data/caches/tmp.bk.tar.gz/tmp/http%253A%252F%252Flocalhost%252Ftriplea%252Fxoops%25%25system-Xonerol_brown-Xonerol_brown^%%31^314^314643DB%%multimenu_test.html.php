<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:include/multimenu_test.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'counter', 'db:include/multimenu_test.html', 1, false),)), $this); ?>
<?php echo smarty_function_counter(array('start' => 0,'print' => false,'assign' => 'count'), $this);?>


      <table class="outer">
                  <th class="header" width="20%">  Smarty     </th><th>     Value               </th></tr>
                  <tr class="odd">      <td>&lt;{$title}&gt;            </td><td>     <?php echo $this->_tpl_vars['title']; ?>
            </td></tr>
                  <tr class="even">     <td>&lt;{$background}&gt;       </td><td>     <?php echo $this->_tpl_vars['background']; ?>
       </td></tr>
                  <tr class="odd">      <td>&lt;{$admin}&gt;            </td><td>     <?php echo $this->_tpl_vars['admin']; ?>
            </td></tr>
                  <tr class="even">     <td>&lt;{$cols}&gt;             </td><td>     <?php echo $this->_tpl_vars['cols']; ?>
             </td></tr>
                  <tr class="odd">      <td>&lt;{$mode}&gt;             </td><td>     <?php echo $this->_tpl_vars['mode']; ?>
             </td></tr>
                  <tr class="even">     <td>&lt;{$banner_url}&gt;       </td><td>     <?php echo $this->_tpl_vars['banner_url']; ?>
       </td></tr>
                  <tr class="odd">      <td>&lt;{$banner}&gt;           </td><td>     <?php echo $this->_tpl_vars['banner']; ?>
           </td></tr>
                  <tr class="odd">      <td>&lt;{$duration}&gt;         </td><td>     <?php echo $this->_tpl_vars['duration']; ?>
         </td></tr>
                  <tr class="even">     <td>&lt;{$transition}&gt;       </td><td>     <?php echo $this->_tpl_vars['transition']; ?>
       </td></tr>
                  <tr class="odd">      <td>&lt;{$image_max_width}&gt;  </td><td>     <?php echo $this->_tpl_vars['image_max_width']; ?>
  </td></tr>
                  <tr class="even">     <td>&lt;{$image_max_height}&gt; </td><td>     <?php echo $this->_tpl_vars['image_max_height']; ?>
 </td></tr>
                  <tr class="odd">      <td>&lt;{$ii}&gt;                </td><td>    <?php echo $this->_tpl_vars['ii']; ?>
              </td></tr>
                  <tr class="odd">      <td>&lt;{$i}&gt;                </td><td>     <?php echo $this->_tpl_vars['i']; ?>
                </td></tr>
       </table>



<hr />

       <table cellspacing="20">
       <tr><td>

       <?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>

         <?php if ($this->_tpl_vars['i'] == $this->_tpl_vars['count']): ?>
         </td>
         <td>
         <?php echo smarty_function_counter(array('start' => 0,'print' => false,'assign' => 'count'), $this);?>

         <?php endif; ?>

         <h4><?php echo $this->_tpl_vars['item']['num']; ?>
. <?php echo $this->_tpl_vars['item']['title']; ?>
</h4>

      <table class="outer">
                  <th class="header" width="20%">  Smarty     </th><th width="80%">     Value               </th></tr>
                  <tr class="odd">     <td>&lt;{$id}&gt;       </td><td>     <?php echo $this->_tpl_vars['item']['id']; ?>
        </td></tr>
                  <tr class="even">    <td>&lt;{$pid}&gt;      </td><td>     <?php echo $this->_tpl_vars['item']['pid']; ?>
       </td></tr>
                  <tr class="odd">     <td>&lt;{$catid}&gt;    </td><td>     <?php echo $this->_tpl_vars['item']['catid']; ?>
     </td></tr>
                  <tr class="even">    <td>&lt;{$type}&gt;     </td><td>     <?php echo $this->_tpl_vars['item']['type']; ?>
      </td></tr>
                  <tr class="odd">     <td>&lt;{$status}&gt;   </td><td>     <?php echo $this->_tpl_vars['item']['status']; ?>
    </td></tr>
                  <tr class="even">    <td>&lt;{$weight}&gt;   </td><td>     <?php echo $this->_tpl_vars['item']['weight']; ?>
    </td></tr>
                  <tr class="odd">     <td>&lt;{$title}&gt;    </td><td>     <?php echo $this->_tpl_vars['item']['title']; ?>
     </td></tr>
                  <tr class="even">    <td>&lt;{$alt_title}&gt;</td><td>     <?php echo $this->_tpl_vars['item']['alt_title']; ?>
 </td></tr>
                  <tr class="odd">     <td>&lt;{$link}&gt;     </td><td style="font-size:80%;">     <?php echo $this->_tpl_vars['item']['link']; ?>
      </td></tr>
                  <tr class="even">    <td>&lt;{$query}&gt;    </td><td>     <?php echo $this->_tpl_vars['item']['query']; ?>
     </td></tr>
                  <tr class="odd">     <td>&lt;{$target}&gt;   </td><td>     <?php echo $this->_tpl_vars['item']['target']; ?>
    </td></tr>
                  <tr class="even">    <td>&lt;{$image}&gt;    </td><td style="font-size:80%;">     <?php echo $this->_tpl_vars['item']['image']; ?>
     </td></tr>
       </table>
                <?php echo smarty_function_counter(array('print' => false,'assign' => 'count'), $this);?>

        <?php endforeach; endif; unset($_from); ?>
        
        </td></tr>
        </table>