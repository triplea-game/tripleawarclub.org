<?php /* Smarty version 2.6.26, created on 2010-05-18 22:08:51
         compiled from db:include/multimenu_xoops_menu.html */ ?>

    <div id="mainmenu">
<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
  <?php if ($this->_tpl_vars['item']['link_status'] == top): ?>    <?php $this->assign('class', 'menuTop'); ?>
  <?php elseif ($this->_tpl_vars['item']['link_status'] == link): ?>   <?php $this->assign('class', 'menuMain'); ?>
  <?php elseif ($this->_tpl_vars['item']['link_status'] == sublink): ?><?php $this->assign('class', 'menuSub'); ?>
  <?php endif; ?>

       <a   class="<?php echo $this->_tpl_vars['class']; ?>
"
            <?php if ($this->_tpl_vars['item']['link']): ?>href="<?php echo $this->_tpl_vars['item']['link']; ?>
"<?php endif; ?>
            <?php echo $this->_tpl_vars['item']['target']; ?>

            title="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"
            <?php if ($this->_tpl_vars['item']['css']): ?> style="<?php echo $this->_tpl_vars['item']['css']; ?>
"<?php endif; ?>
       >

  <?php if ($this->_tpl_vars['item']['image']): ?>
       <img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"
            alt="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"
            <?php echo $this->_tpl_vars['image_width']; ?>
<?php echo $this->_tpl_vars['image_height']; ?>

            align="absmiddle"
       />
  <?php endif; ?>
  <?php echo $this->_tpl_vars['item']['title']; ?>

  <?php if ($this->_tpl_vars['item']['link']): ?></a><?php endif; ?>
<?php endforeach; endif; unset($_from); ?>

    </div>