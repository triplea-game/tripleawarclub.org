<?php /* Smarty version 2.6.26, created on 2010-05-20 12:48:39
         compiled from db:multimenu_block_1.html */ ?>
<fieldset style="padding: 10px;">
  <legend style="font-weight: bold;"><?php echo $this->_tpl_vars['lang_login']; ?>
</legend>
  <form action="user.php" method="post">
    <?php echo $this->_tpl_vars['lang_username']; ?>
 <input type="text" name="uname" size="26" maxlength="25" value="<?php echo $this->_tpl_vars['usercookie']; ?>
" /><br /><br />
    <?php echo $this->_tpl_vars['lang_password']; ?>
 <input type="password" name="pass" size="21" maxlength="32" /><br /><br />
    <?php if (isset ( $this->_tpl_vars['lang_rememberme'] )): ?>
        <input type="checkbox" name="rememberme" value="On" checked /> <?php echo $this->_tpl_vars['lang_rememberme']; ?>
<br /><br />
    <?php endif; ?>
    
    <input type="hidden" name="op" value="login" />
    <input type="hidden" name="xoops_redirect" value="<?php echo $this->_tpl_vars['redirect_page']; ?>
" />
    <input type="submit" value="<?php echo $this->_tpl_vars['lang_login']; ?>
" />
  </form>
  <br />
  <a name="lost"></a>
  <div><?php echo $this->_tpl_vars['lang_notregister']; ?>
<br /></div>
</fieldset>

<br />

<fieldset style="padding: 10px;">
  <legend style="font-weight: bold;"><?php echo $this->_tpl_vars['lang_lostpassword']; ?>
</legend>
  <div><br /><?php echo $this->_tpl_vars['lang_noproblem']; ?>
</div>
  <form action="lostpass.php" method="post">
    <?php echo $this->_tpl_vars['lang_youremail']; ?>
 <input type="text" name="email" size="26" maxlength="60" />&nbsp;&nbsp;<input type="hidden" name="op" value="mailpasswd" /><input type="hidden" name="t" value="<?php echo $this->_tpl_vars['mailpasswd_token']; ?>
" /><input type="submit" value="<?php echo $this->_tpl_vars['lang_sendpassword']; ?>
" />
  </form>
</fieldset>


<?php if ($this->_tpl_vars['block']['css_link']): ?>
<link rel="stylesheet" type="text/css" media="all" href="<?php echo $this->_tpl_vars['xoops_url']; ?>
<?php echo $this->_tpl_vars['block']['css_link']; ?>
" />
<?php endif; ?>

<?php if ($this->_tpl_vars['block']['css']): ?>
<style type="text/css">
<?php echo $this->_tpl_vars['block']['css']; ?>

</style>
<?php endif; ?>

<?php echo $this->_tpl_vars['block']['description']; ?>


<?php $this->assign('id', $this->_tpl_vars['block']['id']); ?>
<?php $this->assign('menu', $this->_tpl_vars['block']['menu']); ?>
<?php $this->assign('background', $this->_tpl_vars['block']['background']); ?>
<?php $this->assign('script_link', $this->_tpl_vars['block']['script_link']); ?>
<?php $this->assign('status', $this->_tpl_vars['block']['status']); ?>
<?php $this->assign('title', $this->_tpl_vars['block']['title']); ?>
<?php $this->assign('description', $this->_tpl_vars['block']['description']); ?>
<?php $this->assign('ii', $this->_tpl_vars['block']['ii']); ?>
<?php $this->assign('i', $this->_tpl_vars['block']['i']); ?>
<?php $this->assign('i_main', $this->_tpl_vars['block']['i_main']); ?>
<?php $this->assign('module', $this->_tpl_vars['block']['module']); ?>
<?php $this->assign('image_width', $this->_tpl_vars['block']['image_width']); ?>
<?php $this->assign('image_height', $this->_tpl_vars['block']['image_height']); ?>
<?php $this->assign('cols', $this->_tpl_vars['block']['cols']); ?>
<?php $this->assign('duration', $this->_tpl_vars['block']['duration']); ?>
<?php $this->assign('transition', $this->_tpl_vars['block']['transition']); ?>
<?php $this->assign('item', $this->_tpl_vars['block']['item']); ?>
<?php $this->assign('mode', $this->_tpl_vars['block']['mode']); ?>

<?php $this->assign('data_list', $this->_tpl_vars['block']['data_list']); ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:".($this->_tpl_vars['mode']), 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php if ($this->_tpl_vars['block']['admin']): ?><hr />
<div align="right"><?php echo $this->_tpl_vars['block']['admin']; ?>
</div>
<?php endif; ?>