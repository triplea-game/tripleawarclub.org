<?php /* Smarty version 2.6.26, created on 2010-07-06 03:37:34
         compiled from db:system_homepage.html */ ?>
