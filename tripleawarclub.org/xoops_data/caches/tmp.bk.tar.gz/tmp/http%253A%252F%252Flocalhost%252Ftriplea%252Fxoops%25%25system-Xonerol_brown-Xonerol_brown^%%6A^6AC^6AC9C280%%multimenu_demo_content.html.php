<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:include/multimenu_demo_content.html */ ?>
<div id="ixt-header_wrap">
 <div id="ixt-header">
  <div id="ixt-header_content_wrap">
   <div id="ixt-header_content">
    <div id="ixt-demo-wrapper">
     <div id="ixt-demo-inner">
     

<?php $this->assign('i', 1); ?>
<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>

<?php if ($this->_tpl_vars['item']['link_status'] == top): ?>

       <div id="ixt-democont<?php echo $this->_tpl_vars['i']; ?>
" class="scrolling-content">
       <div id="ixt-demo<?php echo $this->_tpl_vars['i']; ?>
">
       <h1><?php echo $this->_tpl_vars['item']['title']; ?>
</h1><?php echo $this->_tpl_vars['item']['alt_title']; ?>

       <ul>

       <?php elseif ($this->_tpl_vars['previous_status'] == sublink && $this->_tpl_vars['item']['link_status'] == sublink): ?>

       <li>
       <?php if ($this->_tpl_vars['item']['link']): ?><a href="<?php echo $this->_tpl_vars['item']['link']; ?>
" <?php if ($this->_tpl_vars['item']['popgen']): ?><?php echo $this->_tpl_vars['item']['popgen']; ?>
<?php else: ?><?php echo $this->_tpl_vars['item']['target']; ?>
 <?php endif; ?><?php if ($this->_tpl_vars['item']['alt_title']): ?>title="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
" <?php endif; ?><?php if ($this->_tpl_vars['item']['css']): ?>style="<?php echo $this->_tpl_vars['item']['css']; ?>
"<?php endif; ?>><?php endif; ?>
       <?php if ($this->_tpl_vars['item']['image']): ?><img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"<?php if ($this->_tpl_vars['item']['alt_title']): ?> alt="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?> align="absmiddle" <?php echo $this->_tpl_vars['image_width']; ?>
<?php echo $this->_tpl_vars['image_height']; ?>
 /><?php endif; ?>
       <?php echo $this->_tpl_vars['item']['title']; ?>
<?php if ($this->_tpl_vars['item']['link']): ?></a><br />
       <span style="padding-left:24px;"><?php echo $this->_tpl_vars['item']['alt_title']; ?>
</span><?php endif; ?>
        </li>

        <?php elseif ($this->_tpl_vars['previous_status'] == sublink && $this->_tpl_vars['item']['link_status'] == link): ?>

        <?php $this->assign('i', $this->_tpl_vars['i']+1); ?>
        </ul>
       </div>
      </div>
      <div id="ixt-democont<?php echo $this->_tpl_vars['i']; ?>
" class="scrolling-content">
       <div id="ixt-demo<?php echo $this->_tpl_vars['i']; ?>
">
        <h1><?php echo $this->_tpl_vars['item']['title']; ?>
</h1><?php echo $this->_tpl_vars['item']['alt_title']; ?>

        <ul>
<?php endif; ?>
<?php $this->assign('previous_status', $this->_tpl_vars['item']['link_status']); ?>
<?php endforeach; endif; unset($_from); ?>
        </ul>
       </div>
      </div>

     </div>
    </div>
   </div>
  </div>
  

  <div id="ixt-header_buttons_wrap">
   <div id="ixt-header_buttons">
    <div id="ixt-demo-bar">
     <ul id="ixt-buttons">

<?php $this->assign('i', 1); ?>
<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
<?php if ($this->_tpl_vars['item']['link_status'] == top || $this->_tpl_vars['item']['link_status'] == link): ?>
      <li id="ixt-but_demo<?php echo $this->_tpl_vars['i']; ?>
"><a id="ixt-link<?php echo $this->_tpl_vars['i']; ?>
" href="#" name="ixt-link<?php echo $this->_tpl_vars['i']; ?>
" class="active" onClick="toggleActive(this);return false;"><div id="ixt-but_text"><?php echo $this->_tpl_vars['item']['title']; ?>
</div></a></li>
<?php $this->assign('i', $this->_tpl_vars['i']+1); ?>
      <?php endif; ?>
<?php endforeach; endif; unset($_from); ?>

     </ul>
    </div>
   </div>
  </div>
 </div>
</div>