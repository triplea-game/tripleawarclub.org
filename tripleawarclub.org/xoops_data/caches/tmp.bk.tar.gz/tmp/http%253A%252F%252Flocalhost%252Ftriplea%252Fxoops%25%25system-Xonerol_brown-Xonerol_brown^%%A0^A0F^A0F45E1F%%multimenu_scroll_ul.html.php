<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:include/multimenu_scroll_ul.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'counter', 'db:include/multimenu_scroll_ul.html', 1, false),)), $this); ?>
<?php echo smarty_function_counter(array('start' => 0,'print' => false,'assign' => 'count'), $this);?>


<marquee onmouseover="this.stop();"
         onmouseout="this.start();"
	 direction="up"
	 style="width:100%;height:160px;"
	 scrollamount="3"
	 scrolldelay="3">

<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
<?php if ($this->_tpl_vars['item']['link_status'] == top): ?><ol>
<?php elseif ($this->_tpl_vars['item']['link_status'] == sublink && $this->_tpl_vars['previous_status'] == top): ?><ol>
<?php elseif ($this->_tpl_vars['item']['link_status'] == sublink && $this->_tpl_vars['previous_status'] == link): ?><ol>
<?php elseif ($this->_tpl_vars['item']['link_status'] == link && $this->_tpl_vars['previous_status'] == sublink): ?></ol>
<?php endif; ?><?php $this->assign('previous_status', $this->_tpl_vars['item']['link_status']); ?>

                  <li class="<?php echo $this->_tpl_vars['item']['type']; ?>
">

                   <?php if ($this->_tpl_vars['item']['link']): ?>
                      <a   class="<?php echo $this->_tpl_vars['item']['link_status']; ?>
"
                           href="<?php echo $this->_tpl_vars['item']['link']; ?>
"
                           <?php echo $this->_tpl_vars['item']['target']; ?>

                           title="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"
                      >
                    <?php endif; ?>
                    <?php if ($this->_tpl_vars['item']['image']): ?>
                      
                      <img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"
                           alt="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"
                           align="absmiddle"
                           <?php echo $this->_tpl_vars['image_width']; ?>
<?php echo $this->_tpl_vars['image_height']; ?>

                      />

                    <?php endif; ?>

                      <?php echo $this->_tpl_vars['item']['title']; ?>


                      <?php if ($this->_tpl_vars['item']['link']): ?></a><?php endif; ?>
                      
                      </li>
        <?php endforeach; endif; unset($_from); ?>
<?php if ($this->_tpl_vars['previous_status'] == sublink): ?>   </ol>
<?php endif; ?>

         </ol>

</marquee>