<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:include/multimenu_ul_simple.html */ ?>
<?php $this->assign('ul', 0); ?>
<ul>

<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
<?php if ($this->_tpl_vars['previous_status'] == sublink && $this->_tpl_vars['item']['link_status'] == link): ?>
<?php unset($this->_sections['foo']);
$this->_sections['foo']['name'] = 'foo';
$this->_sections['foo']['start'] = (int)0;
$this->_sections['foo']['loop'] = is_array($_loop=$this->_tpl_vars['ul']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['foo']['step'] = ((int)1) == 0 ? 1 : (int)1;
$this->_sections['foo']['show'] = true;
$this->_sections['foo']['max'] = $this->_sections['foo']['loop'];
if ($this->_sections['foo']['start'] < 0)
    $this->_sections['foo']['start'] = max($this->_sections['foo']['step'] > 0 ? 0 : -1, $this->_sections['foo']['loop'] + $this->_sections['foo']['start']);
else
    $this->_sections['foo']['start'] = min($this->_sections['foo']['start'], $this->_sections['foo']['step'] > 0 ? $this->_sections['foo']['loop'] : $this->_sections['foo']['loop']-1);
if ($this->_sections['foo']['show']) {
    $this->_sections['foo']['total'] = min(ceil(($this->_sections['foo']['step'] > 0 ? $this->_sections['foo']['loop'] - $this->_sections['foo']['start'] : $this->_sections['foo']['start']+1)/abs($this->_sections['foo']['step'])), $this->_sections['foo']['max']);
    if ($this->_sections['foo']['total'] == 0)
        $this->_sections['foo']['show'] = false;
} else
    $this->_sections['foo']['total'] = 0;
if ($this->_sections['foo']['show']):

            for ($this->_sections['foo']['index'] = $this->_sections['foo']['start'], $this->_sections['foo']['iteration'] = 1;
                 $this->_sections['foo']['iteration'] <= $this->_sections['foo']['total'];
                 $this->_sections['foo']['index'] += $this->_sections['foo']['step'], $this->_sections['foo']['iteration']++):
$this->_sections['foo']['rownum'] = $this->_sections['foo']['iteration'];
$this->_sections['foo']['index_prev'] = $this->_sections['foo']['index'] - $this->_sections['foo']['step'];
$this->_sections['foo']['index_next'] = $this->_sections['foo']['index'] + $this->_sections['foo']['step'];
$this->_sections['foo']['first']      = ($this->_sections['foo']['iteration'] == 1);
$this->_sections['foo']['last']       = ($this->_sections['foo']['iteration'] == $this->_sections['foo']['total']);
?></li>
</ul>
<?php endfor; endif; ?>
<?php $this->assign('ul', 0); ?>
 <?php endif; ?>
<?php if (( $this->_tpl_vars['previous_status'] == top || $this->_tpl_vars['previous_status'] == link ) && $this->_tpl_vars['item']['link_status'] == sublink): ?>
<?php $this->assign('ul', $this->_tpl_vars['ul']+1); ?>

  <ul>
<?php endif; ?>
<?php if (( $this->_tpl_vars['previous_status'] == sublink && $this->_tpl_vars['previous_pid'] != $this->_tpl_vars['item']['pid'] ) && $this->_tpl_vars['item']['link_status'] == sublink): ?>
<?php if ($this->_tpl_vars['ul'] == 1): ?>
<?php $this->assign('ul', $this->_tpl_vars['ul']+1); ?>

    <ul>
<?php else: ?>
<?php unset($this->_sections['foo']);
$this->_sections['foo']['name'] = 'foo';
$this->_sections['foo']['start'] = (int)0;
$this->_sections['foo']['loop'] = is_array($_loop=1) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['foo']['step'] = ((int)1) == 0 ? 1 : (int)1;
$this->_sections['foo']['show'] = true;
$this->_sections['foo']['max'] = $this->_sections['foo']['loop'];
if ($this->_sections['foo']['start'] < 0)
    $this->_sections['foo']['start'] = max($this->_sections['foo']['step'] > 0 ? 0 : -1, $this->_sections['foo']['loop'] + $this->_sections['foo']['start']);
else
    $this->_sections['foo']['start'] = min($this->_sections['foo']['start'], $this->_sections['foo']['step'] > 0 ? $this->_sections['foo']['loop'] : $this->_sections['foo']['loop']-1);
if ($this->_sections['foo']['show']) {
    $this->_sections['foo']['total'] = min(ceil(($this->_sections['foo']['step'] > 0 ? $this->_sections['foo']['loop'] - $this->_sections['foo']['start'] : $this->_sections['foo']['start']+1)/abs($this->_sections['foo']['step'])), $this->_sections['foo']['max']);
    if ($this->_sections['foo']['total'] == 0)
        $this->_sections['foo']['show'] = false;
} else
    $this->_sections['foo']['total'] = 0;
if ($this->_sections['foo']['show']):

            for ($this->_sections['foo']['index'] = $this->_sections['foo']['start'], $this->_sections['foo']['iteration'] = 1;
                 $this->_sections['foo']['iteration'] <= $this->_sections['foo']['total'];
                 $this->_sections['foo']['index'] += $this->_sections['foo']['step'], $this->_sections['foo']['iteration']++):
$this->_sections['foo']['rownum'] = $this->_sections['foo']['iteration'];
$this->_sections['foo']['index_prev'] = $this->_sections['foo']['index'] - $this->_sections['foo']['step'];
$this->_sections['foo']['index_next'] = $this->_sections['foo']['index'] + $this->_sections['foo']['step'];
$this->_sections['foo']['first']      = ($this->_sections['foo']['iteration'] == 1);
$this->_sections['foo']['last']       = ($this->_sections['foo']['iteration'] == $this->_sections['foo']['total']);
?>
   </li>
  </ul> 
<?php endfor; endif; ?>
</li>
<?php $this->assign('ul', 1); ?>
  <?php endif; ?>
<?php endif; ?>
<?php if (( $this->_tpl_vars['previous_status'] == top && $this->_tpl_vars['item']['link_status'] == link ) || ( $this->_tpl_vars['previous_status'] == link && $this->_tpl_vars['item']['link_status'] == link ) || ( $this->_tpl_vars['previous_status'] == sublink && $this->_tpl_vars['item']['link_status'] == sublink && $this->_tpl_vars['previous_pid'] == $this->_tpl_vars['item']['pid'] )): ?></li>
<?php endif; ?>
     <li>[<?php echo $this->_tpl_vars['ul']; ?>
 & <?php echo $this->_tpl_vars['previous_pid']; ?>
=<?php echo $this->_tpl_vars['item']['pid']; ?>
] : <?php echo $this->_tpl_vars['item']['title']; ?>
<?php $this->assign('previous_status', $this->_tpl_vars['item']['link_status']); ?><?php $this->assign('previous_pid', $this->_tpl_vars['item']['pid']); ?><?php endforeach; endif; unset($_from); ?>
<?php unset($this->_sections['ul']);
$this->_sections['ul']['name'] = 'ul';
$this->_sections['ul']['start'] = (int)0;
$this->_sections['ul']['loop'] = is_array($_loop=$this->_tpl_vars['ul']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['ul']['step'] = ((int)1) == 0 ? 1 : (int)1;
$this->_sections['ul']['show'] = true;
$this->_sections['ul']['max'] = $this->_sections['ul']['loop'];
if ($this->_sections['ul']['start'] < 0)
    $this->_sections['ul']['start'] = max($this->_sections['ul']['step'] > 0 ? 0 : -1, $this->_sections['ul']['loop'] + $this->_sections['ul']['start']);
else
    $this->_sections['ul']['start'] = min($this->_sections['ul']['start'], $this->_sections['ul']['step'] > 0 ? $this->_sections['ul']['loop'] : $this->_sections['ul']['loop']-1);
if ($this->_sections['ul']['show']) {
    $this->_sections['ul']['total'] = min(ceil(($this->_sections['ul']['step'] > 0 ? $this->_sections['ul']['loop'] - $this->_sections['ul']['start'] : $this->_sections['ul']['start']+1)/abs($this->_sections['ul']['step'])), $this->_sections['ul']['max']);
    if ($this->_sections['ul']['total'] == 0)
        $this->_sections['ul']['show'] = false;
} else
    $this->_sections['ul']['total'] = 0;
if ($this->_sections['ul']['show']):

            for ($this->_sections['ul']['index'] = $this->_sections['ul']['start'], $this->_sections['ul']['iteration'] = 1;
                 $this->_sections['ul']['iteration'] <= $this->_sections['ul']['total'];
                 $this->_sections['ul']['index'] += $this->_sections['ul']['step'], $this->_sections['ul']['iteration']++):
$this->_sections['ul']['rownum'] = $this->_sections['ul']['iteration'];
$this->_sections['ul']['index_prev'] = $this->_sections['ul']['index'] - $this->_sections['ul']['step'];
$this->_sections['ul']['index_next'] = $this->_sections['ul']['index'] + $this->_sections['ul']['step'];
$this->_sections['ul']['first']      = ($this->_sections['ul']['iteration'] == 1);
$this->_sections['ul']['last']       = ($this->_sections['ul']['iteration'] == $this->_sections['ul']['total']);
?>
</li>
</ul>
<?php endfor; endif; ?>

</li>
</ul>