<?php /* Smarty version 2.6.26, created on 2010-05-18 21:48:53
         compiled from db:multimenu_footer.html */ ?>
</div>
</div>

<?php if ($this->_tpl_vars['admin']): ?>
	<div class="itemFoot"><?php echo $this->_tpl_vars['admin']; ?>
</div>
<?php endif; ?>

<?php echo $this->_tpl_vars['footer']; ?>


<!-- End - Module:<?php echo $this->_tpl_vars['module']; ?>
 - Template:<?php echo $this->_tpl_vars['mode']; ?>
 -->