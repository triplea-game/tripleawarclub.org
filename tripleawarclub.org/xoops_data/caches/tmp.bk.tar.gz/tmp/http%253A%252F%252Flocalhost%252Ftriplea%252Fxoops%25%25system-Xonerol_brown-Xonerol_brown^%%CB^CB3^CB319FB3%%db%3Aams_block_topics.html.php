<?php /* Smarty version 2.6.26, created on 2010-05-13 10:50:19
         compiled from db:ams_block_topics.html */ ?>
<div style="text-align: center;"><form name="newstopicform" action="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/AMS/index.php" method="get"><?php echo $this->_tpl_vars['block']['selectbox']; ?>
</form></div>