<?php /* Smarty version 2.6.26, created on 2010-05-13 10:51:30
         compiled from db:system_homepage.html */ ?>
