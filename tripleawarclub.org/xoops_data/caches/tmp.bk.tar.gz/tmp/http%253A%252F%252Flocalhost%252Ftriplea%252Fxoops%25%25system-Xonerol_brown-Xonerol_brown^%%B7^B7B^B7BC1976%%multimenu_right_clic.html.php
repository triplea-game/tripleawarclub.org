<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:include/multimenu_right_clic.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'strip_tags', 'db:include/multimenu_right_clic.html', 10, false),)), $this); ?>
<div id="ejs_context_box">

<script language="JavaScript1.2">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
ejs_context_elemt = new Array;
<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
<?php $this->assign('title', ((is_array($_tmp=$this->_tpl_vars['item']['title'])) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp))); ?>

<?php if ($this->_tpl_vars['item']['link_status'] == top): ?>
     <?php $this->assign('count', 0); ?>
     ejs_context_elemt[<?php echo $this->_tpl_vars['count']; ?>
] = "<?php echo $this->_tpl_vars['title']; ?>
|<?php echo $this->_tpl_vars['item']['link_status']; ?>
|document.location.href='<?php echo $this->_tpl_vars['item']['link']; ?>
'|<?php echo $this->_tpl_vars['item']['image']; ?>
";
<?php elseif ($this->_tpl_vars['item']['link_status'] == link): ?>
     <?php $this->assign('count', $this->_tpl_vars['count']+1); ?>
     ejs_context_elemt[<?php echo $this->_tpl_vars['count']; ?>
] = '';
     <?php $this->assign('count', $this->_tpl_vars['count']+1); ?>
     ejs_context_elemt[<?php echo $this->_tpl_vars['count']; ?>
] = "<?php echo $this->_tpl_vars['title']; ?>
|<?php echo $this->_tpl_vars['item']['link_status']; ?>
|document.location.href='<?php echo $this->_tpl_vars['item']['link']; ?>
'|<?php echo $this->_tpl_vars['item']['image']; ?>
";
<?php elseif ($this->_tpl_vars['item']['link_status'] == sublink): ?>
     <?php $this->assign('count', $this->_tpl_vars['count']+1); ?>
     ejs_context_elemt[<?php echo $this->_tpl_vars['count']; ?>
] = "<?php echo $this->_tpl_vars['title']; ?>
|<?php echo $this->_tpl_vars['item']['link_status']; ?>
|document.location.href='<?php echo $this->_tpl_vars['item']['link']; ?>
'|<?php echo $this->_tpl_vars['item']['image']; ?>
";
<?php endif; ?>
<?php endforeach; endif; unset($_from); ?>

</script>

<?php if ($this->_tpl_vars['script_link']): ?>
<script language="JavaScript"
        type="text/javascript"
        src="<?php echo $this->_tpl_vars['xoops_url']; ?>
<?php echo $this->_tpl_vars['script_link']; ?>
">
</script>
<?php endif; ?>