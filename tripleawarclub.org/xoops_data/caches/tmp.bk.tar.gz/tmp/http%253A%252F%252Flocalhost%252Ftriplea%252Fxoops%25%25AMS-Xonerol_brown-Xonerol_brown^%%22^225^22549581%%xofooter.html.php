<?php /* Smarty version 2.6.26, created on 2010-05-14 11:43:25
         compiled from Xonerol_brown/xotpl/xofooter.html */ ?>
<div id="xo-footer" class="<?php echo $this->_tpl_vars['xoops_dirname']; ?>
">
<!-- footer infos defined in the preferences of the site -->

Powered by <a href="http://xoops.sourceforge.net/" target="_blank">XOOPS</a> | theme modified from <a href="http://www.xoopsland.com/modules/extgallery/public-photo.php?photoId=11" target="_blank">xoopsland</a>

<!--  end  footer infos defined in the preferences of the site -->
</div>