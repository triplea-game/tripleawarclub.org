<?php /* Smarty version 2.6.26, created on 2010-05-13 10:50:19
         compiled from db:system_block_themes.html */ ?>
<div style="text-align: center;">
<form action="index.php" method="post">
<?php echo $this->_tpl_vars['block']['theme_select']; ?>

</form>
</div>