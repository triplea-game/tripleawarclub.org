<?php /* Smarty version 2.6.26, created on 2010-07-06 03:58:44
         compiled from db:profile_userinfo.html */ ?>
<h2 class="siteheader"><?php echo $this->_tpl_vars['uname']; ?>
's Profile</h2>
        <?php if ($this->_tpl_vars['avatar']): ?>

   	  <p><img src="<?php echo $this->_tpl_vars['avatar']; ?>
" alt="<?php echo $this->_tpl_vars['uname']; ?>
" /></p>

   	  <?php endif; ?>

        <?php if ($this->_tpl_vars['email']): ?>

        <p><a href="mailto:<?php echo $this->_tpl_vars['email']; ?>
"><?php echo $this->_tpl_vars['email']; ?>
</a></p>

        <?php endif; ?>
        

        <?php if (! $this->_tpl_vars['user_ownpage'] && $this->_tpl_vars['xoops_isuser'] == true): ?>
        <br />

        <form name="usernav" action="user.php" method="post">

            <input type="button" value="<?php echo @_PROFILE_MA_SENDPM; ?>
" onclick="javascript:openWithSelfMain('<?php echo $this->_tpl_vars['xoops_url']; ?>
/pmlite.php?send2=1&amp;to_userid=<?php echo $this->_tpl_vars['user_uid']; ?>
', 'pmlite', 450, 380);" />

        </form>

        <?php endif; ?>        



<br style="clear: both;" />

<?php if ($this->_tpl_vars['user_ownpage'] == true): ?>

    <form name="usernav" action="user.php" method="post">

        <input type="button" value="<?php echo $this->_tpl_vars['lang_editprofile']; ?>
" onclick="location='<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/edituser.php'" />

        <input type="button" value="<?php echo $this->_tpl_vars['lang_changepassword']; ?>
" onclick="location='<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/changepass.php'" />

        <?php if ($this->_tpl_vars['user_changeemail']): ?>

            <input type="button" value="<?php echo @_PROFILE_MA_CHANGEMAIL; ?>
" onclick="location='<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/changemail.php'" />

        <?php endif; ?>



        <?php if ($this->_tpl_vars['user_candelete'] == true): ?>

            <form method="post" action="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/user.php">

                <input type="hidden" name="op" value="delete">

                <input type="hidden" name="uid" value="<?php echo $this->_tpl_vars['user_uid']; ?>
">

                <input type="button" value="<?php echo $this->_tpl_vars['lang_deleteaccount']; ?>
" onclick="submit();" />

            </form>

        <?php endif; ?>



        <input type="button" value="<?php echo $this->_tpl_vars['lang_avatar']; ?>
" onclick="location='edituser.php?op=avatarform'" />

        <input type="button" value="<?php echo $this->_tpl_vars['lang_inbox']; ?>
" onclick="location='<?php echo $this->_tpl_vars['xoops_url']; ?>
/viewpmsg.php'" />

        <input type="button" value="<?php echo $this->_tpl_vars['lang_logout']; ?>
" onclick="location='<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/user.php?op=logout'" />

    </form>

<?php elseif ($this->_tpl_vars['xoops_isadmin'] != false): ?>

        <form method="post" action="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/admin/deactivate.php">

        <input type="button" value="<?php echo $this->_tpl_vars['lang_editprofile']; ?>
" onclick="location='<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/admin/user.php?op=edit&amp;id=<?php echo $this->_tpl_vars['user_uid']; ?>
'" />

        <input type="hidden" name="uid" value="<?php echo $this->_tpl_vars['user_uid']; ?>
" />

        <?php if ($this->_tpl_vars['userlevel'] == 1): ?>

            <input type="hidden" name="level" value="0" />

            <input type="button" value="<?php echo @_PROFILE_MA_DEACTIVATE; ?>
" onclick="submit();" />

        <?php else: ?>

            <input type="hidden" name="level" value="1" />

            <input type="button" value="<?php echo @_PROFILE_MA_ACTIVATE; ?>
" onclick="submit();" />

        <?php endif; ?>

        </form>

<?php endif; ?>



<br style="clear: both;" />



<?php $_from = $this->_tpl_vars['categories']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['category']):
?>

    <?php if (isset ( $this->_tpl_vars['category']['fields'] )): ?>

        <div class="profile-list-category" id="profile-category-<?php echo $this->_tpl_vars['category']['cat_id']; ?>
">

            <table class="outer" cellpadding="4" cellspacing="1">

                <tr>

                  <th colspan="2" align="center"><?php echo $this->_tpl_vars['category']['cat_title']; ?>
</th>

                </tr>

                <?php $_from = $this->_tpl_vars['category']['fields']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['field']):
?>

                    <tr>

                        <td class="head"><?php echo $this->_tpl_vars['field']['title']; ?>
</td>

                        <td class="even"><?php echo $this->_tpl_vars['field']['value']; ?>
</td>

                    </tr>

                <?php endforeach; endif; unset($_from); ?>

            </table>

        </div>

    <?php endif; ?>

<?php endforeach; endif; unset($_from); ?>