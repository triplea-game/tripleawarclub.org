<?php /* Smarty version 2.6.26, created on 2010-05-20 12:48:26
         compiled from db:multimenu_block_2.html */ ?>
<?php if ($this->_tpl_vars['block']['css_link']): ?>
<link rel="stylesheet" type="text/css" media="all" href="<?php echo $this->_tpl_vars['xoops_url']; ?>
<?php echo $this->_tpl_vars['block']['css_link']; ?>
" />
<?php endif; ?>

<?php if ($this->_tpl_vars['block']['css']): ?>
<style type="text/css">
<?php echo $this->_tpl_vars['block']['css']; ?>

</style>
<?php endif; ?>

<?php echo $this->_tpl_vars['block']['description']; ?>


<?php $this->assign('id', $this->_tpl_vars['block']['id']); ?>
<?php $this->assign('menu', $this->_tpl_vars['block']['menu']); ?>
<?php $this->assign('background', $this->_tpl_vars['block']['background']); ?>
<?php $this->assign('script_link', $this->_tpl_vars['block']['script_link']); ?>
<?php $this->assign('status', $this->_tpl_vars['block']['status']); ?>
<?php $this->assign('title', $this->_tpl_vars['block']['title']); ?>
<?php $this->assign('description', $this->_tpl_vars['block']['description']); ?>
<?php $this->assign('ii', $this->_tpl_vars['block']['ii']); ?>
<?php $this->assign('i', $this->_tpl_vars['block']['i']); ?>
<?php $this->assign('i_main', $this->_tpl_vars['block']['i_main']); ?>
<?php $this->assign('module', $this->_tpl_vars['block']['module']); ?>
<?php $this->assign('image_width', $this->_tpl_vars['block']['image_width']); ?>
<?php $this->assign('image_height', $this->_tpl_vars['block']['image_height']); ?>
<?php $this->assign('cols', $this->_tpl_vars['block']['cols']); ?>
<?php $this->assign('duration', $this->_tpl_vars['block']['duration']); ?>
<?php $this->assign('transition', $this->_tpl_vars['block']['transition']); ?>
<?php $this->assign('item', $this->_tpl_vars['block']['item']); ?>
<?php $this->assign('mode', $this->_tpl_vars['block']['mode']); ?>

<?php $this->assign('data_list', $this->_tpl_vars['block']['data_list']); ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:".($this->_tpl_vars['mode']), 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php if ($this->_tpl_vars['block']['admin']): ?><hr />
<div align="right"><?php echo $this->_tpl_vars['block']['admin']; ?>
</div>
<?php endif; ?>