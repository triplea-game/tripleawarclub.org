<?php /* Smarty version 2.6.26, created on 2010-05-18 21:48:53
         compiled from db:multimenu_header.html */ ?>

<?php if ($this->_tpl_vars['banner']): ?><div align="center">
              <?php echo $this->_tpl_vars['banner']; ?>
</div><p /><?php endif; ?>

<?php if ($this->_tpl_vars['status'] == 1): ?><a href="."><?php echo $this->_tpl_vars['index']; ?>
</a> > <?php echo $this->_tpl_vars['title']; ?>
<?php endif; ?>
<div class="item"<?php if ($this->_tpl_vars['background']): ?> style="background: url('<?php echo $this->_tpl_vars['background']; ?>
') transparent no-repeat center center;"<?php endif; ?>>
	<div class="itemHead">
         <?php echo $this->_tpl_vars['title']; ?>

             <?php if ($this->_tpl_vars['tpl_list'] && $this->_tpl_vars['item_display_selectmode']): ?>
             <span style="padding-left:65%;">
                   <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:multimenu_tpl.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
             </span>
             <?php endif; ?>
        </div><p />
	<div class="itemBody">
	
	<div class="itemText"><?php if ($this->_tpl_vars['image']): ?><img src="<?php echo $this->_tpl_vars['image']; ?>
" align="left" /><?php endif; ?><?php echo $this->_tpl_vars['text']; ?>
</div>