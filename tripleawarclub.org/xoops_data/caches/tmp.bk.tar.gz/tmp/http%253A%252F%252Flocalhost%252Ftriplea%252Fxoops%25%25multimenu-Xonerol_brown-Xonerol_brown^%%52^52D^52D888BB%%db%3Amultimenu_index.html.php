<?php /* Smarty version 2.6.26, created on 2010-05-18 21:48:53
         compiled from db:multimenu_index.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'db:multimenu_index.html', 25, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:multimenu_header.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

     <table class="outer" style="margin:3px;">
            <tr>
                <th width="20%">
                    <?php echo $this->_tpl_vars['item']; ?>

                </th>

                <?php if ($this->_tpl_vars['is_description']): ?>
                <th width="<?php if ($this->_tpl_vars['is_admins']): ?>30<?php else: ?>80%<?php endif; ?>">
                    <?php echo $this->_tpl_vars['description']; ?>

                </th>
                <?php endif; ?>

                <?php if ($this->_tpl_vars['is_admin']): ?>
                <th width="50%" colspan="2">
                    <?php echo $this->_tpl_vars['admins']; ?>

                </th>
                <?php endif; ?>


            </tr>

     <?php $_from = $this->_tpl_vars['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
     <?php echo smarty_function_cycle(array('values' => 'odd,even','assign' => 'class'), $this);?>

            <tr>
                <td class="<?php echo $this->_tpl_vars['class']; ?>
" style="text-align:center;">

                        <a href="<?php echo $this->_tpl_vars['item']['urw']; ?>
" 
                           title="<?php echo $this->_tpl_vars['item']['title']; ?>
">
                       <?php if ($this->_tpl_vars['item']['logo'] && $this->_tpl_vars['is_image']): ?>
                        <img src="<?php echo $this->_tpl_vars['item']['logo']; ?>
" 
                             width="<?php echo $this->_tpl_vars['item']['thumb_max_width']; ?>
"
                             alt="<?php echo $this->_tpl_vars['item']['title']; ?>
" 
                             align="absmiddle" /><br /><?php endif; ?>
                        <?php echo $this->_tpl_vars['item']['title']; ?>

                        </a>

                </td>

                <?php if ($this->_tpl_vars['is_description']): ?>
                <td class="<?php echo $this->_tpl_vars['class']; ?>
">
                    <?php echo $this->_tpl_vars['item']['description']; ?>

                </td>
                <?php endif; ?>

                <?php if ($this->_tpl_vars['is_admin']): ?>
                <td class="<?php echo $this->_tpl_vars['class']; ?>
">
                    <?php echo $this->_tpl_vars['item']['status']; ?>

                </td>
                <?php endif; ?>

                <?php if ($this->_tpl_vars['is_admin']): ?>
                <td class="<?php echo $this->_tpl_vars['class']; ?>
">
                    <?php echo $this->_tpl_vars['item']['admin']; ?>

                </td>
                <?php endif; ?>
                

            </tr>

     <?php endforeach; endif; unset($_from); ?>
     </table>
<p />
<?php if ($this->_tpl_vars['pagenav']): ?>
     <div style="padding-left:70%;width:30%; align:center;"><?php echo $this->_tpl_vars['pagenav']; ?>
</div>
<?php endif; ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:multimenu_footer.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>