<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:include/multimenu_images.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'math', 'db:include/multimenu_images.html', 9, false),)), $this); ?>
<?php $this->assign('i', 0); ?>
<table>
<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>

  <?php if ($this->_tpl_vars['item']['link_status'] == top): ?><tr>
  <?php elseif ($this->_tpl_vars['i'] >= $this->_tpl_vars['cols']): ?></tr><tr><?php $this->assign('i', 0); ?>
  <?php endif; ?><?php $this->assign('i', $this->_tpl_vars['i']+1); ?>

                  <td width="<?php echo smarty_function_math(array('equation' => "x/y",'x' => 100,'y' => $this->_tpl_vars['cols'],'format' => "%.0f"), $this);?>
" 
                      class="<?php echo $this->_tpl_vars['item']['link_status']; ?>
"
                      align="center">
                   <?php if ($this->_tpl_vars['item']['link']): ?>

                      <a   href="<?php echo $this->_tpl_vars['item']['link']; ?>
"
                           <?php if ($this->_tpl_vars['item']['popgen']): ?><?php echo $this->_tpl_vars['item']['popgen']; ?>
<?php else: ?>
                           <?php echo $this->_tpl_vars['item']['target']; ?>

                           <?php endif; ?>
                           <?php if ($this->_tpl_vars['item']['alt_title']): ?>title="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?>
                           <?php if ($this->_tpl_vars['item']['css']): ?>style="<?php echo $this->_tpl_vars['item']['css']; ?>
"<?php endif; ?>
                      >
                    <?php endif; ?>
                    <?php if ($this->_tpl_vars['item']['image']): ?>
                      <img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"
                           <?php if ($this->_tpl_vars['item']['alt_title']): ?>alt="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?>
                           <?php echo $this->_tpl_vars['image_width']; ?>
<?php echo $this->_tpl_vars['image_height']; ?>

                      /><br />
                      <?php endif; ?>
                      <?php echo $this->_tpl_vars['item']['title']; ?>

                      <?php if ($this->_tpl_vars['item']['link']): ?></a><?php endif; ?>
                      </td>
<?php endforeach; endif; unset($_from); ?>
<?php unset($this->_sections[""]);
$this->_sections[""]['name'] = "";
$this->_sections[""]['loop'] = is_array($_loop=$this->_tpl_vars['cols']-$this->_tpl_vars['i']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections[""]['show'] = true;
$this->_sections[""]['max'] = $this->_sections[""]['loop'];
$this->_sections[""]['step'] = 1;
$this->_sections[""]['start'] = $this->_sections[""]['step'] > 0 ? 0 : $this->_sections[""]['loop']-1;
if ($this->_sections[""]['show']) {
    $this->_sections[""]['total'] = $this->_sections[""]['loop'];
    if ($this->_sections[""]['total'] == 0)
        $this->_sections[""]['show'] = false;
} else
    $this->_sections[""]['total'] = 0;
if ($this->_sections[""]['show']):

            for ($this->_sections[""]['index'] = $this->_sections[""]['start'], $this->_sections[""]['iteration'] = 1;
                 $this->_sections[""]['iteration'] <= $this->_sections[""]['total'];
                 $this->_sections[""]['index'] += $this->_sections[""]['step'], $this->_sections[""]['iteration']++):
$this->_sections[""]['rownum'] = $this->_sections[""]['iteration'];
$this->_sections[""]['index_prev'] = $this->_sections[""]['index'] - $this->_sections[""]['step'];
$this->_sections[""]['index_next'] = $this->_sections[""]['index'] + $this->_sections[""]['step'];
$this->_sections[""]['first']      = ($this->_sections[""]['iteration'] == 1);
$this->_sections[""]['last']       = ($this->_sections[""]['iteration'] == $this->_sections[""]['total']);
?><td>&nbsp;</td><?php endfor; endif; ?>
</tr>
</table>