<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:multimenu_tpl.html */ ?>
<select size="1"
        name="item_mode"
        onchange="location='item.php?id=<?php echo $this->_tpl_vars['id']; ?>
&mode='+this.options[this.selectedIndex].value">

        <?php echo $this->_tpl_vars['tpl_list']; ?>


</select>