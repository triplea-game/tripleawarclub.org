<?php /* Smarty version 2.6.26, created on 2010-05-23 23:15:19
         compiled from db:profile_editprofile.html */ ?>
<h2 class="siteheader">Edit Profile</h2>


<?php if ($this->_tpl_vars['stop']): ?>

    <div class='errorMsg' style="text-align: left;"><?php echo $this->_tpl_vars['stop']; ?>
</div>

    <br style='clear: both;' />

<?php endif; ?>


<?php $this->_smarty_include(array('smarty_include_tpl_file' => "db:profile_form.html", 'smarty_include_vars' => array('xoForm' => $this->_tpl_vars['userinfo'])));
 ?>