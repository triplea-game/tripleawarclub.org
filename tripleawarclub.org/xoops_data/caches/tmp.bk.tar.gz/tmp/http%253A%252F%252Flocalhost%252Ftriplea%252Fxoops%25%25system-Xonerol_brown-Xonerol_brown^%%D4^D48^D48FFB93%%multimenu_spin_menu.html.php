<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:include/multimenu_spin_menu.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'strip_tags', 'db:include/multimenu_spin_menu.html', 18, false),array('modifier', 'stristr', 'db:include/multimenu_spin_menu.html', 19, false),)), $this); ?>
<script language="JavaScript"
        type="text/javascript" 
        src="<?php echo $this->_tpl_vars['xoops_url']; ?>
<?php echo $this->_tpl_vars['script_link']; ?>
">
</script>

<script language="JavaScript"
        type="text/javascript">
                
        if (document.getElementById){
        document.write('<div id="spinanchor" style="height:'+eval(eye.h+20)+'; text-align:left;"></div>')
        eye.anchor=document.getElementById('spinanchor')
        eye.spinmenu();
        eye.x+=getposOffset(eye.anchor, "right") //relatively position it
        eye.y+=getposOffset(eye.anchor, "bottom")  //relatively position it

        //menuitem: eye.spinmenuitem(text, link, target)
        <?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
        <?php $this->assign('title', ((is_array($_tmp=$this->_tpl_vars['item']['title'])) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp))); ?>
        eye.spinmenuitem("<?php echo $this->_tpl_vars['title']; ?>
", "<?php echo $this->_tpl_vars['item']['link']; ?>
", "<?php if (((is_array($_tmp=$this->_tpl_vars['item']['target'])) ? $this->_run_mod_handler('stristr', true, $_tmp, '_blank') : stristr($_tmp, '_blank')) || ((is_array($_tmp=$this->_tpl_vars['item']['target'])) ? $this->_run_mod_handler('stristr', true, $_tmp, 'wclose') : stristr($_tmp, 'wclose'))): ?>_blank<?php endif; ?>")
        <?php endforeach; endif; unset($_from); ?>
        eye.spinmenuclose();
        }

</script>


 <div style="height:100px;"></div>