<?php /* Smarty version 2.6.26, created on 2010-05-14 12:43:20
         compiled from db:system_block_dummy.html */ ?>
<?php echo $this->_tpl_vars['block']['content']; ?>