<?php /* Smarty version 2.6.26, created on 2010-07-06 03:59:23
         compiled from Xonerol_brown/xotpl/xoscripts.html */ ?>
<!-- Include files javascripts -->
<script type="text/javascript" src="<?php echo 'http://www.tripleawarclub.org/jseffects/others/textsizer.js'; ?>"></script>

<!-- include style sheets Css of Scripts -->

<!-- png transparence under ie -->
<!--[if lte IE 6]>
	<script type="text/javascript">
		var WEBFX_PNG_PATTERN=".*.png";
		var WEBFX_PNG_BLANK = "<?php 
echo 'http://www.tripleawarclub.org/jseffects/img/blank.gif'; ?>";
	</script>
	<style type="text/css">
	img { behavior: url(<?php 
echo 'http://www.tripleawarclub.org/jseffects/pngbehavior.htc'; ?>); }
	</style>
<![endif]-->

  <!-- jQuery -->
  <script type='text/javascript' src='<?php 
echo 'http://www.tripleawarclub.org/themes/Xonerol_brown/js/jquery-1.4.2.min.js'; ?>'></script>

  <!-- Ladder jQuery Accordion Menu -->
  <script type='text/javascript' src='<?php 
echo 'http://www.tripleawarclub.org/themes/Xonerol_brown/js/menu.js'; ?>'></script>