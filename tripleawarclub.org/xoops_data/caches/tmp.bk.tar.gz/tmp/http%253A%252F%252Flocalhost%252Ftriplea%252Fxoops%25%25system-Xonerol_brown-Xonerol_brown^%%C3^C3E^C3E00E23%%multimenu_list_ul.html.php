<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:list/multimenu_list_ul.html */ ?>
<div class="head"><?php echo $this->_tpl_vars['other']; ?>
 <?php echo $this->_tpl_vars['item']; ?>
</div>
<ul>
   <?php $_from = $this->_tpl_vars['items_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
    <nobr><li>
        <?php if ($this->_tpl_vars['item']['id'] != $this->_tpl_vars['id']): ?>
          <a href="<?php echo $this->_tpl_vars['item']['urw']; ?>
" title="<?php echo $this->_tpl_vars['item']['title']; ?>
 ">
           <?php echo $this->_tpl_vars['item']['title']; ?>

          </a>
        <?php else: ?>
            <?php echo $this->_tpl_vars['item']['title']; ?>

        <?php endif; ?>
        </li>
    </nobr>
  <?php endforeach; endif; unset($_from); ?>
</ul>