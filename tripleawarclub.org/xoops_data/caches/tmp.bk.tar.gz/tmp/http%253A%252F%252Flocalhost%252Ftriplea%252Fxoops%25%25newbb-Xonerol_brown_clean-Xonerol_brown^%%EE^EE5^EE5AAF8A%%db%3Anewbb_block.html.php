<?php /* Smarty version 2.6.26, created on 2010-05-14 12:43:20
         compiled from db:newbb_block.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'db:newbb_block.html', 49, false),)), $this); ?>
<div class='column span-6'>

	<h2><a href="http://www.tripleawarclub.org/modules/newbb/">Forums &raquo;</a></h2>

</div>
<div class='column span-5 last'>

	<form action="http://www.tripleawarclub.org/modules/newbb/search.php" method="post" name="search" id="search">
	<input name="term" id="term" type="text" value="Search Forums.." onclick="this.value='';" onfocus="this.select()" onblur="this.value=!this.value?'Search Forums..':this.value;"/>
	<input type="hidden" name="forum" id="forum" value="all" />
	<input type="hidden" name="sortby" id="sortby" value="p.post_time desc" />
	<input type="hidden" name="searchin" id="searchin" value="both" />
	<input type="image" src="images/page_white_find.png" name="submit" value="submit" style="vertical-align:middle;"/>
	</form>

</div>

<hr/>

<ul id="tabs" class='forums'>
	<li><a href='#latestposts' class='selected'>Latest Posts</a></li>
	<li><a href='#forumslist'>Forums List</a></li>
</ul>

<div id="latestposts">

	<table class="outer" cellspacing="1">

	  <thead>

	  <tr> 

	    <th><?php echo @_MB_NEWBB_TOPIC; ?>
</th>

	    <th><?php echo @_MB_NEWBB_RPLS; ?>
</th>

	    <th><?php echo @_MB_NEWBB_VIEWS; ?>
</th>

	    <th><?php echo @_MB_NEWBB_LPOST; ?>
</th>
	    <th>Sub-<?php echo @_MB_NEWBB_FORUM; ?>
</th>

	  </tr>

	</thead>
	<tbody>

	  <?php $_from = $this->_tpl_vars['block']['topics']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['topic']):
?>

	  <tr class="<?php echo smarty_function_cycle(array('values' => "even,odd"), $this);?>
">

	    <td>

			<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/newbb/viewtopic.php?topic_id=<?php echo $this->_tpl_vars['topic']['id']; ?>
&amp;forum=<?php echo $this->_tpl_vars['topic']['forum_id']; ?>
">
			<?php if ($this->_tpl_vars['topic']['topic_subject']): ?>

			<?php echo $this->_tpl_vars['topic']['topic_subject']; ?>


			<?php endif; ?>

			<?php echo $this->_tpl_vars['topic']['title']; ?>
</a>
			<br/> by <a href="userinfo.php?uid=<?php echo $this->_tpl_vars['topic']['topic_creator_id']; ?>
"><?php echo $this->_tpl_vars['topic']['topic_creator_name']; ?>
</a>
			</td>

	    <td align="center"><?php echo $this->_tpl_vars['topic']['replies']; ?>
</td>

	    <td align="center"><?php echo $this->_tpl_vars['topic']['views']; ?>
</td>

	    <td align="right">
	    <a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/newbb/viewtopic.php?topic_id=<?php echo $this->_tpl_vars['topic']['id']; ?>
&amp;forum=<?php echo $this->_tpl_vars['topic']['forum_id']; ?>
&amp;post_id=<?php echo $this->_tpl_vars['topic']['post_id']; ?>
#forumpost<?php echo $this->_tpl_vars['topic']['post_id']; ?>
">
	    <?php echo $this->_tpl_vars['topic']['time']; ?>
</a><br/>by <?php echo $this->_tpl_vars['topic']['topic_poster']; ?>
</td>
	     <td><a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/newbb/viewforum.php?forum=<?php echo $this->_tpl_vars['topic']['forum_id']; ?>
"><?php echo $this->_tpl_vars['topic']['forum_name']; ?>
</a></td>

	  </tr>

	  <?php endforeach; endif; unset($_from); ?>

	</tbody>

	</table>

</div>