<?php /* Smarty version 2.6.26, created on 2010-05-14 09:14:23
         compiled from file:/var/www/triplea/xoops/modules/comp/templates/username_options.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'capitalize', 'file:/var/www/triplea/xoops/modules/comp/templates/username_options.html', 6, false),array('function', 'cycle', 'file:/var/www/triplea/xoops/modules/comp/templates/username_options.html', 8, false),)), $this); ?>
<?php echo ''; ?><?php echo '<img style="vertical-align:middle" src=\'images/dogtags/dogtags.png\'onmouseover="return overlib(\'<table class=&quot;outer&quot; style=&quot;width:400px&quot;><tr><th colspan=&quot;2&quot;>'; ?><?php echo $this->_tpl_vars['name']; ?><?php echo '\\\'s '; ?><?php echo ((is_array($_tmp=@_COMP_OPTIONS)) ? $this->_run_mod_handler('capitalize', true, $_tmp) : smarty_modifier_capitalize($_tmp)); ?><?php echo '</th></tr>'; ?><?php $_from = $this->_tpl_vars['options']['rules']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['rulefor'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['rulefor']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['rule']):
        $this->_foreach['rulefor']['iteration']++;
?><?php echo '<tr class=&quot;'; ?><?php echo smarty_function_cycle(array('values' => "even,odd"), $this);?><?php echo '&quot;><td><img style=&quot;height:32px;&quot; height=32 src=&quot;images/dogtags/'; ?><?php echo $this->_tpl_vars['rule']['name']; ?><?php echo '.png&quot;></td><td style=&quot;vertical-align:middle&quot;>'; ?><?php echo $this->_tpl_vars['rule']['desc']; ?><?php echo '</td></tr>'; ?><?php endforeach; endif; unset($_from); ?><?php echo ''; ?><?php $_from = $this->_tpl_vars['options']['luck']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['luckfor'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['luckfor']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['luck']):
        $this->_foreach['luckfor']['iteration']++;
?><?php echo '<tr class=&quot;'; ?><?php echo smarty_function_cycle(array('values' => "even,odd"), $this);?><?php echo '&quot;><td><img style=&quot;height:32px;&quot; height=32 src=&quot;images/dogtags/'; ?><?php echo $this->_tpl_vars['luck']['name']; ?><?php echo '.png&quot;></td><td style=&quot;vertical-align:middle&quot;>'; ?><?php echo $this->_tpl_vars['luck']['desc']; ?><?php echo '</td></tr>'; ?><?php endforeach; endif; unset($_from); ?><?php echo ''; ?><?php $_from = $this->_tpl_vars['options']['mode']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['modefor'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['modefor']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['mode']):
        $this->_foreach['modefor']['iteration']++;
?><?php echo '<tr class=&quot;'; ?><?php echo smarty_function_cycle(array('values' => "even,odd"), $this);?><?php echo '&quot;><td><img style=&quot;height:32px;&quot; height=32 src=&quot;images/dogtags/'; ?><?php echo $this->_tpl_vars['mode']['name']; ?><?php echo '.png&quot;></td><td style=&quot;vertical-align:middle&quot;>'; ?><?php echo $this->_tpl_vars['mode']['desc']; ?><?php echo '</td></tr>'; ?><?php endforeach; endif; unset($_from); ?><?php echo '</table>\', FGCOLOR, \'\', BGCOLOR, \'\');" onmouseout="return nd();">'; ?>


<?php if ($this->_tpl_vars['local_status'] != 0): ?>
<?php echo $this->_tpl_vars['name']; ?>
 (retired)
<?php else: ?>
<a style="vertical-align:middle
<?php if ($this->_tpl_vars['global_status'] != 0): ?>
	;color:red
<?php endif; ?>
" href="profile.php?uid=<?php echo $this->_tpl_vars['uid']; ?>
"><?php echo $this->_tpl_vars['name']; ?>
</a>
<?php endif; ?>