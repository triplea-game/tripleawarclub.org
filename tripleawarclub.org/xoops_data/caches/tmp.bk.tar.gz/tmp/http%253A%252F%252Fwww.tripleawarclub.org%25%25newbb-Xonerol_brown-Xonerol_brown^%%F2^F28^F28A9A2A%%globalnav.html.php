<?php /* Smarty version 2.6.26, created on 2010-07-06 03:59:10
         compiled from Xonerol_brown/xotpl/globalnav.html */ ?>
    <div id="xo-globalnav">
      <ul>
        <li><a href="<?php echo 'http://www.tripleawarclub.org/'; ?>" <?php if ($this->_tpl_vars['homeStyle']): ?> class="menu_active"<?php endif; ?>>Home</a></li>
        <li><a href="<?php echo 'http://www.tripleawarclub.org/modules/AMS/'; ?>index.php?storytopic=1" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'AMS'): ?>_active<?php endif; ?>">Strategy</a></li> 
        <li><a href="<?php echo 'http://www.tripleawarclub.org/modules/newbb/'; ?>" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'newbb'): ?>_active<?php endif; ?>">Forums</a></li>
        <li><a href="<?php echo 'http://www.tripleawarclub.org/modules/comp/'; ?>" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'comp'): ?>_active<?php endif; ?>">Ladder</a></li>      
	<li><a href="http://sites.google.com/site/tripleaerniebommel/home/links" class="menu">Links</a></li>
<!--        <li><a href="<?php echo 'http://www.tripleawarclub.org/modules/wflinks/'; ?>" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'wflinks'): ?>_active<?php endif; ?>">Links</a></li>-->
      <!-- <li><a href="<?php echo 'http://www.tripleawarclub.org/modules/smartfaq/'; ?>" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'smartfaq'): ?>_active<?php endif; ?>">FAQ</a></li>-->
<!-- Example -->
 <!-- <li><a href="<?php echo 'http://www.tripleawarclub.org/modules/my_module/'; ?>" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'my_module'): ?>_active<?php endif; ?>">My module</a></li> -->
      </ul>
    </div>