<?php /* Smarty version 2.6.26, created on 2010-05-13 10:51:23
         compiled from /var/www/triplea/xoops/modules/system/class/gui/oxygen/xotpl/xo_accordion.html */ ?>
<div class="CPbigTitle" style="background-image: url(<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/img/brightside.png'; ?>)"><?php echo @_MD_CPANEL_OVERVIEW; ?>
</div>
            <!-- strst accordion menu -->
            <div id="firstpane" class="menu_list">
                <!-- menu 1 -->
                <p class="menu_head"><?php echo @_MD_CPANEL_OVERVIEW; ?>
</p>
                <div class="menu_body">
                    <table>
                        <tr>
                            <td><?php echo @_MD_OXYGEN_VERSION_XOOPS; ?>
</td>
                            <td><?php echo $this->_tpl_vars['xoops_version']; ?>
</td>
                        </tr>
                        <tr>
                            <td><?php echo @_MD_OXYGEN_VERSION_PHP; ?>
</td>
                            <td><?php echo $this->_tpl_vars['lang_php_vesion']; ?>
</td>
                        </tr>
                        <tr>
                            <td><?php echo @_MD_OXYGEN_VERSION_MYSQL; ?>
</td>
                            <td><?php echo $this->_tpl_vars['lang_mysql_version']; ?>
</td>
                        </tr>
                        <tr>
                            <td><?php echo @_MD_OXYGEN_Server_API; ?>
</td>
                            <td><?php echo $this->_tpl_vars['lang_server_api']; ?>
</td>
                        </tr>
                        <tr>
                            <td><?php echo @_MD_OXYGEN_OS; ?>
</td>
                            <td><?php echo $this->_tpl_vars['lang_os_name']; ?>
</td>
                        </tr>
                        <tr>
                            <td>safe_mode</td>
                            <td><?php echo $this->_tpl_vars['safe_mode']; ?>
</td>
                        </tr>
                        <tr>
                            <td>register_globals</td>
                            <td><?php echo $this->_tpl_vars['register_globals']; ?>
</td>
                        </tr>
                        <tr>
                            <td>magic_quotes_gpc</td>
                            <td><?php echo $this->_tpl_vars['magic_quotes_gpc']; ?>
</td>
                        </tr>
                        <tr>
                            <td>allow_url_fopen</td>
                            <td><?php echo $this->_tpl_vars['allow_url_fopen']; ?>
</td>
                        </tr>
                        <tr>
                            <td>fsockopen</td>
                            <td><?php echo $this->_tpl_vars['fsockopen']; ?>
</td>
                        </tr>
                        <tr>
                            <td>post_max_size</td>
                            <td><?php echo $this->_tpl_vars['post_max_size']; ?>
</td>
                        </tr>
                        <tr>
                            <td>max_input_time</td>
                            <td><?php echo $this->_tpl_vars['max_input_time']; ?>
</td>
                        </tr>
                        <tr>
                            <td>output_buffering</td>
                            <td><?php echo $this->_tpl_vars['output_buffering']; ?>
</td>
                        </tr>
                        <tr>
                            <td>max_execution_time</td>
                            <td><?php echo $this->_tpl_vars['max_execution_time']; ?>
</td>
                        </tr>
                        <tr>
                            <td>memory_limit</td>
                            <td><?php echo $this->_tpl_vars['memory_limit']; ?>
</td>
                        </tr>
                        <tr>
                            <td>file_uploads</td>
                            <td><?php echo $this->_tpl_vars['file_uploads']; ?>
</td>
                        </tr>
                        <tr>
                            <td>upload_max_filesize</td>
                            <td><?php echo $this->_tpl_vars['upload_max_filesize']; ?>
</td>
                        </tr>
                    </table>
                </div>
               <!-- menu 2 -->
                <p class="menu_head"><?php echo @_MD_OXYGEN_XOOPS_LICENSE; ?>
</p>
                <div class="menu_body" id="sidemenulinks">
                   <table>
                         <tr>
                            <td><?php echo @_MD_OXYGEN_KEY; ?>
</td>
                            <td><?php echo @XOOPS_LICENSE_KEY; ?>
</td>
                        </tr>
                        <tr>
                            <td><?php echo @_MD_OXYGEN_LICENSE; ?>
</td>
                            <td><a class="tooltip" rel="external" href="http://www.gnu.org/licenses/gpl.html" title="<?php echo @XOOPS_LICENSE_CODE; ?>
"><?php echo @XOOPS_LICENSE_CODE; ?>
</a></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><a class="tooltip" rel="external" href="http://www.gnu.org/licenses/gpl-2.0.html" title="<?php echo @XOOPS_LICENSE_TEXT; ?>
"><?php echo @XOOPS_LICENSE_TEXT; ?>
</a></td>
                        </tr>
                    </table>
                </div>
                <!-- menu 3 -->
                <p class="menu_head"><?php echo @_MD_OXYGEN_ABOUT; ?>
</p>
                <div class="menu_body">
                    <?php echo @_MD_OXYGEN_ABOUT_TEXT; ?>

                </div>
                <!-- menu 4 -->
                <p class="menu_head"><?php echo @_MD_OXYGEN_XOOPS_LINKS; ?>
</p>
                <div class="menu_body" id="sidemenulinks">
                    <table>
                        <tr>
                            <td><a rel="external" href="http://www.xoops.org"><?php echo @_MD_OXYGEN_XOOPSPROJECT; ?>
</a></td>
                            <td><a rel="external" href="http://www.xoops.org/modules/xoopspartners"><?php echo @_MD_OXYGEN_LOCALSUPPORT; ?>
</a></td>
                        </tr>
                        <tr>
                            <td><a rel="external" href="http://www.xoops.org/modules/core"><?php echo @_MD_OXYGEN_XOOPSCORE; ?>
</a></td>
                            <td><a rel="external" href="http://www.xoops.org/modules/extgallery"><?php echo @_MD_OXYGEN_XOOPSTHEME; ?>
</a></td>
                        </tr>
                        <tr>
                            <td><a rel="external" href="http://www.xoops.org/modules/mediawiki/index.php/Main_Page"><?php echo @_MD_OXYGEN_XOOPSWIKI; ?>
</a></td>
                            <td><a rel="external" href="http://www.xoops.org/modules/news/article.php?storyid=4534"><?php echo @_MD_OXYGEN_XOOPSBOOKS; ?>
</a></td>
                        </tr>
                        <tr>
                            <td><a rel="external" href="http://www.xoops.org/modules/news/index.php?storytopic=2"><?php echo @_MD_OXYGEN_NEWMODULE; ?>
</a></td>
                            <td><a rel="external" href="http://www.xoops.org/modules/smartfaq"><?php echo @_MD_OXYGEN_XOOPSFAQ; ?>
</a></td>
                        </tr>
                        <tr>
                            <td><a rel="external" href="http://xoops.svn.sourceforge.net/viewvc/xoops"><?php echo @_MD_OXYGEN_CODESVN; ?>
</a></td>
                            <td><a rel="external" href="http://sourceforge.net/tracker/?func=add&amp;group_id=41586&amp;atid=430840"><?php echo @_MD_OXYGEN_REPORTBUG; ?>
</a></td>
                        </tr>
                    </table>
                </div>
                <!-- menu 5 -->
                <p class="menu_head"><?php echo @_MD_OXYGEN_XDONATIONS; ?>
</p>
                <div class="menu_body">
                    <?php echo @_MD_OXYGEN_XDONATIONS_TEXT; ?>

                </div>
                <!-- menu 6 -->
                <p class="menu_head"><?php echo @_MD_OXYGEN_XGIFTSHOP; ?>
</p>
                <div class="menu_body">
                    <div class="xgiftshop">
                        <a rel="external" class="tooltip" href="http://www.cafepress.com/xoopsfoundation/" title="<?php echo @_MD_OXYGEN_XGIFTSHOP; ?>
"><img src="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/img/xgiftshopbutton.png'; ?>" /></a>
                        <br />                        
                    </div>
                </div>
            </div>