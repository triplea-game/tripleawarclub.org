<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:include/multimenu_table.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'db:include/multimenu_table.html', 14, false),)), $this); ?>
<table class="Outer">
       <tr>
          <th width="25%" colspan="2"><?php echo $this->_tpl_vars['title']; ?>
</th>
          <th width="75%"><?php echo $this->_tpl_vars['item']; ?>
</th>
       </tr>

<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>

  <?php if ($this->_tpl_vars['item']['link_status'] == top || $this->_tpl_vars['item']['link_status'] == link): ?>
  <?php if ($this->_tpl_vars['previous_status'] == sublink): ?></ol>
         </td>
       </tr>
  <?php endif; ?>
       <tr class="<?php echo smarty_function_cycle(array('values' => "odd,even"), $this);?>
">
         <td style="font-weight:bold;text-align:center;">
                   <?php echo $this->_tpl_vars['item']['num_main']; ?>
.
         </td>
         <td style="font-weight:bold;text-align:center;">
                   <?php if ($this->_tpl_vars['item']['link']): ?>

                      <a   href="<?php echo $this->_tpl_vars['item']['link']; ?>
"
                           <?php echo $this->_tpl_vars['item']['target']; ?>

                           <?php if ($this->_tpl_vars['item']['alt_title']): ?>title="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?>
                           <?php if ($this->_tpl_vars['item']['css']): ?>style="<?php echo $this->_tpl_vars['item']['css']; ?>
"<?php endif; ?>
                      >
                    <?php endif; ?>
                    <?php if ($this->_tpl_vars['item']['image']): ?>
                      <img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"
                           <?php if ($this->_tpl_vars['item']['alt_title']): ?>alt="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?>
                           <?php echo $this->_tpl_vars['image_width']; ?>
<?php echo $this->_tpl_vars['image_height']; ?>

                      /><br />
                      <?php endif; ?>
                      <?php echo $this->_tpl_vars['item']['title']; ?>

                      <?php if ($this->_tpl_vars['item']['link']): ?></a><?php endif; ?>

         </td>
         <td>
                      <?php echo $this->_tpl_vars['item']['alt_title']; ?>

  <?php elseif ($this->_tpl_vars['item']['link_status'] == sublink): ?>
  <?php if ($this->_tpl_vars['previous_status'] == top || $this->_tpl_vars['previous_status'] == link): ?><ol><?php endif; ?>
                     <?php if ($this->_tpl_vars['item']['link']): ?>
                      <li>
                      <a   href="<?php echo $this->_tpl_vars['item']['link']; ?>
"
                           <?php echo $this->_tpl_vars['item']['target']; ?>

                           <?php if ($this->_tpl_vars['item']['alt_title']): ?>title="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?>
                           <?php if ($this->_tpl_vars['item']['css']): ?>style="<?php echo $this->_tpl_vars['item']['css']; ?>
"<?php endif; ?>
                      >
                    <?php endif; ?>
                    <?php if ($this->_tpl_vars['item']['image']): ?>
                      <img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"
                           <?php if ($this->_tpl_vars['item']['alt_title']): ?>alt="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?>
                           align="absmiddle"
                           <?php echo $this->_tpl_vars['image_width']; ?>
<?php echo $this->_tpl_vars['image_height']; ?>

                      />
                      <?php endif; ?>
                      <?php echo $this->_tpl_vars['item']['title']; ?>

                      <?php if ($this->_tpl_vars['item']['link']): ?></a><?php endif; ?>
                      </li>
  <?php endif; ?>

        <?php $this->assign('previous_status', $this->_tpl_vars['item']['link_status']); ?>
        <?php endforeach; endif; unset($_from); ?>
        <?php if ($this->_tpl_vars['previous_status'] == sublink): ?></ol><?php endif; ?>
          </td>
        </tr>
</table>