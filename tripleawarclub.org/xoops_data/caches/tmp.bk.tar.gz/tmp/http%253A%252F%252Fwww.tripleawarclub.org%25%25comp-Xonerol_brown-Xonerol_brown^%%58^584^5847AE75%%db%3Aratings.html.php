<?php /* Smarty version 2.6.26, created on 2010-07-06 12:13:07
         compiled from db:ratings.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'capitalize', 'db:ratings.html', 1, false),)), $this); ?>
<h2 class="siteheader"><?php echo $this->_tpl_vars['params']['profile']['uname']; ?>
's <?php echo ((is_array($_tmp=@_COMP_RATINGS)) ? $this->_run_mod_handler('capitalize', true, $_tmp) : smarty_modifier_capitalize($_tmp)); ?>
</h2>

<p>Your overall rating is: <?php echo $this->_tpl_vars['params']['profile']['karma_rating']; ?>
%(+<?php echo $this->_tpl_vars['params']['profile']['num_positive']; ?>
, <?php echo $this->_tpl_vars['params']['profile']['num_neutral']; ?>
,-<?php echo $this->_tpl_vars['params']['profile']['num_negative']; ?>
).</p><br>

<h3 class="comp">Ratings Listing</h3>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "file:".($this->_tpl_vars['xoops_rootpath'])."/modules/comp/templates/ratings_table.html", 'smarty_include_vars' => array('params' => $this->_tpl_vars['params'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>