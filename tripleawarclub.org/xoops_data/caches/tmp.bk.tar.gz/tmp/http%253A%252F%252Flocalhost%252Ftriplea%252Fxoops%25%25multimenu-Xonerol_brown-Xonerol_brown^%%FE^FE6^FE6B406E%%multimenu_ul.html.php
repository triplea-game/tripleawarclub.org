<?php /* Smarty version 2.6.26, created on 2010-05-18 21:55:42
         compiled from db:include/multimenu_ul.html */ ?>

<ul>
<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>

  <?php if ($this->_tpl_vars['item']['link_status'] == top): ?>
  <?php elseif ($this->_tpl_vars['previous_status'] == top && $this->_tpl_vars['item']['link_status'] == sublink): ?><ol>
  <?php elseif ($this->_tpl_vars['previous_status'] == link && $this->_tpl_vars['item']['link_status'] == sublink): ?><ol>
  <?php elseif ($this->_tpl_vars['previous_status'] == sublink && $this->_tpl_vars['item']['link_status'] == link): ?>   </ol>
  <?php endif; ?><?php $this->assign('previous_status', $this->_tpl_vars['item']['link_status']); ?>

                  <li>
                   <?php if ($this->_tpl_vars['item']['link']): ?>

                      <a   href="<?php echo $this->_tpl_vars['item']['link']; ?>
"
                           <?php if ($this->_tpl_vars['item']['popgen']): ?><?php echo $this->_tpl_vars['item']['popgen']; ?>
<?php else: ?>
                           <?php echo $this->_tpl_vars['item']['target']; ?>

                           <?php endif; ?>
                           <?php if ($this->_tpl_vars['item']['alt_title']): ?>title="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?>
                           <?php if ($this->_tpl_vars['item']['css']): ?>style="<?php echo $this->_tpl_vars['item']['css']; ?>
"<?php endif; ?>
                      >
                    <?php endif; ?>
                    <?php if ($this->_tpl_vars['item']['image']): ?>
                      <img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"
                           <?php if ($this->_tpl_vars['item']['alt_title']): ?>alt="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?>
                           align="absmiddle"
                           <?php echo $this->_tpl_vars['image_width']; ?>
<?php echo $this->_tpl_vars['image_height']; ?>

                      />
                      <?php endif; ?>
                      <?php echo $this->_tpl_vars['item']['title']; ?>

                      <?php if ($this->_tpl_vars['item']['link']): ?></a><?php endif; ?>
                      </li>
        <?php endforeach; endif; unset($_from); ?>
<?php if ($this->_tpl_vars['previous_status'] == sublink): ?>   </ol>
<?php endif; ?> 
</ul>
