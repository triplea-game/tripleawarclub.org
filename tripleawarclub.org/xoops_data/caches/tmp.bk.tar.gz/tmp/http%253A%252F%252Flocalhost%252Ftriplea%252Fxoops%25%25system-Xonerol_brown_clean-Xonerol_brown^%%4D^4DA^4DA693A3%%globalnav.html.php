<?php /* Smarty version 2.6.26, created on 2010-05-14 12:43:21
         compiled from Xonerol_brown_clean/xotpl/globalnav.html */ ?>
    <div id="xo-globalnav">
      <ul>
        <li><a href="<?php echo 'http://localhost/triplea/xoops/'; ?>">Home</a></li>
        <li><a href="<?php echo 'http://localhost/triplea/xoops/modules/newbb/'; ?>" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'newbb'): ?>_active<?php endif; ?>">Forums</a></li>
        <li><a href="<?php echo 'http://localhost/triplea/xoops/modules/comp/'; ?>" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'comp'): ?>_active<?php endif; ?>">Ladder</a></li>      
	<li><a href="http://sites.google.com/site/tripleaerniebommel/home/links" class="menu">Links</a></li>
<!--        <li><a href="<?php echo 'http://localhost/triplea/xoops/modules/wflinks/'; ?>" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'wflinks'): ?>_active<?php endif; ?>">Links</a></li>-->
       <li><a href="<?php echo 'http://localhost/triplea/xoops/modules/smartfaq/'; ?>" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'smartfaq'): ?>_active<?php endif; ?>">FAQ</a></li>
<!-- Example -->
 <!-- <li><a href="<?php echo 'http://localhost/triplea/xoops/modules/my_module/'; ?>" class="menu<?php if ($this->_tpl_vars['xoops_dirname'] == 'my_module'): ?>_active<?php endif; ?>">My module</a></li> -->
      </ul>
    </div>