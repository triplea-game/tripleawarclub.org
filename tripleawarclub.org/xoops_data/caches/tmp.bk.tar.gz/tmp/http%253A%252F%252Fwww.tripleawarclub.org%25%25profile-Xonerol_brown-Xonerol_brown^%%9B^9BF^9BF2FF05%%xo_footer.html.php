<?php /* Smarty version 2.6.26, created on 2010-07-06 12:50:37
         compiled from /var/www/vhosts/tripleawarclub.org/public_html/modules/system/class/gui/oxygen/xotpl/xo_footer.html */ ?>
<div id='xo-footer'>
<?php echo @_MD_OXYGEN_POWERED_BY; ?>
 <?php echo $this->_tpl_vars['xoops_version']; ?>

<br /><br /><?php echo $this->_tpl_vars['xoops_footer']; ?>
<br /><br />
<a id="rss" rel="external" href="<?php echo 'http://www.tripleawarclub.org/backend.php'; ?>" title="<?php echo @_MD_OXYGEN_RSS; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/img/feed.png'; ?>" /></a>
<br />
<a rel="external" href="http://sourceforge.net/projects/xoops/"><img src="http://sflogo.sourceforge.net/sflogo.php?group_id=41586&type=9" border="0" alt="<?php echo @_MD_OXYGEN_SOURCEFORGE_TEXT; ?>
" title="<?php echo @_MD_OXYGEN_SOURCEFORGE_TEXT; ?>
" /></a>
</div>