<?php /* Smarty version 2.6.26, created on 2010-05-13 10:50:19
         compiled from db:ams_block_authors.html */ ?>
<div>
    <ul>
        <?php $_from = $this->_tpl_vars['block']['authors']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['author']):
?>
            <li>
                <a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/userinfo.php?uid=<?php echo $this->_tpl_vars['author']['uid']; ?>
"><?php echo $this->_tpl_vars['author']['name']; ?>
</a> (<?php echo $this->_tpl_vars['author']['count']; ?>
)
            </li>
        <?php endforeach; endif; unset($_from); ?>
    </ul>
</div>