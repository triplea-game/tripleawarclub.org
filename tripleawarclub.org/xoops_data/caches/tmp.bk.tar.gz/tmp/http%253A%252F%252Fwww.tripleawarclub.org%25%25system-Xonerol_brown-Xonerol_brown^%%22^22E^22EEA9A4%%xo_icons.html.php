<?php /* Smarty version 2.6.26, created on 2010-07-06 03:38:08
         compiled from /var/www/vhosts/tripleawarclub.org/public_html/modules/system/class/gui/oxygen/xotpl/xo_icons.html */ ?>
<div class="CPbigTitle" style="background-image: url(<?php echo $this->_tpl_vars['theme_img']; ?>
/cp.png); "><?php echo @_CPHOME; ?>
</div>
<!-- start slideshow  -->
<div class="systemicons">
    <div class="cpicon" >
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=banners'; ?>" title="<?php echo @_MD_AM_BANS_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/banners.png'; ?>" /><br /><span><?php echo @_MD_AM_BANS; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=blocksadmin'; ?>" title="<?php echo @_MD_AM_BKAD_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/blocks.png'; ?>" /><br /><span><?php echo @_MD_AM_BKAD; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=groups'; ?>" title="<?php echo @_MD_AM_ADGS_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/groups.png'; ?>" /><br /><span><?php echo @_MD_AM_ADGS; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=images'; ?>" title="<?php echo @_MD_AM_IMAGES_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/images.png'; ?>" /><br /><span><?php echo @_MD_AM_IMAGES; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=modulesadmin'; ?>" title="<?php echo @_MD_AM_MDAD_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/modules.png'; ?>" /><br /><span><?php echo @_MD_AM_MDAD; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=preferences'; ?>" title="<?php echo @_MD_AM_PREF_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/prefs.png'; ?>" /><br /><span><?php echo @_MD_AM_PREF; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=smilies'; ?>" title="<?php echo @_MD_AM_SMLS_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/smilies.png'; ?>" /><br /><span><?php echo @_MD_AM_SMLS; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=userrank'; ?>" title="<?php echo @_MD_AM_RANK_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/userrank.png'; ?>" /><br /><span><?php echo @_MD_AM_RANK; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=users'; ?>" title="<?php echo @_MD_AM_USER_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/edituser.png'; ?>" /><br /><span><?php echo @_MD_AM_USER; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=findusers'; ?>" title="<?php echo @_MD_AM_FINDUSER_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/finduser.png'; ?>" /><br /><span><?php echo @_MD_AM_FINDUSER; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=mailusers'; ?>" title="<?php echo @_MD_AM_MLUS_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/mailuser.png'; ?>" /><br /><span><?php echo @_MD_AM_MLUS; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=avatars'; ?>" title="<?php echo @_MD_AM_AVATARS_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/avatar.png'; ?>" /><br /><span><?php echo @_MD_AM_AVATARS; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=tplsets'; ?>" title="<?php echo @_MD_AM_TPLSETS_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/tpls.png'; ?>" /><br /><span><?php echo @_MD_AM_TPLSETS; ?>
</span></a>
        <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/modules/system/admin.php?fct=comments'; ?>" title="<?php echo @_MD_AM_COMMENTS_HELP; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/icons/comments.png'; ?>" /><br /><span><?php echo @_MD_AM_COMMENTS; ?>
</span></a>
    </div>
</div>