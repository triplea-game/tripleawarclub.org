<?php /* Smarty version 2.6.26, created on 2010-05-13 10:41:19
         compiled from db:newbb_index.html */ ?>
<div id="index_welcome">
	<div class="title"><a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/"><?php echo $this->_tpl_vars['lang_welcomemsg']; ?>
</a></div>
	<div class="desc"><?php echo @_MD_TOSTART; ?>
</div>
	<div class="visit"><?php echo $this->_tpl_vars['lang_currenttime']; ?>

		<br /><?php echo $this->_tpl_vars['lang_lastvisit']; ?>

		<br /><?php echo @_MD_TOTALTOPICSC; ?>
<strong><?php echo $this->_tpl_vars['total_topics']; ?>
</strong> | <?php echo @_MD_TOTALPOSTSC; ?>
<strong><?php echo $this->_tpl_vars['total_posts']; ?>
</strong>
	</div>
</div>
<div class="clear"></div>

<?php if ($this->_tpl_vars['viewer_level'] == 2 && $this->_tpl_vars['mode'] > 0): ?>
	<div style="padding: 5px;float: right; text-align:right;">
	
	<?php echo @_MD_TOPIC; ?>
: 
	<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/viewall.php?type=active#admin" target="_self" title="<?php echo @_MD_TYPE_ADMIN; ?>
"><?php echo @_MD_TYPE_ADMIN; ?>
</a> | 
	<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/viewall.php?type=pending#admin" target="_self" title="<?php echo @_MD_TYPE_PENDING; ?>
"><?php echo @_MD_TYPE_PENDING; ?>
</a> | 
	<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/viewall.php?type=deleted#admin" target="_self" title="<?php echo @_MD_TYPE_DELETED; ?>
"><?php echo @_MD_TYPE_DELETED; ?>
</a>
	<br style="clear:both;" /> 
	
	<?php echo @_MD_POST2; ?>
: 
	<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/viewpost.php?type=active#admin" target="_self" title="<?php echo @_MD_TYPE_ADMIN; ?>
"><?php echo @_MD_TYPE_ADMIN; ?>
</a> | 
	<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/viewpost.php?type=pending#admin" target="_self" title="<?php echo @_MD_TYPE_PENDING; ?>
"><?php echo @_MD_TYPE_PENDING; ?>
</a> | 
	<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/viewpost.php?type=deleted#admin" target="_self" title="<?php echo @_MD_TYPE_DELETED; ?>
"><?php echo @_MD_TYPE_DELETED; ?>
</a>
	<br style="clear:both;" /> 
	
	<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/moderate.php" target="_self" title="<?php echo @_MD_TYPE_SUSPEND; ?>
"><?php echo @_MD_TYPE_SUSPEND; ?>
</a> | 
	<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/admin/index.php" target="_self" title="<?php echo @_MD_ADMINCP; ?>
"><?php echo @_MD_ADMINCP; ?>
</a>
	
	</div>
	<br />
	<div class="clear"></div>
<?php endif; ?>

<div class="dropdown">
<?php if ($this->_tpl_vars['menumode'] == 0): ?>

	<select
		name="mainoption" id="mainoption"
		class="menu"
		onchange="if(this.options[this.selectedIndex].value.length >0 )	{ window.document.location=this.options[this.selectedIndex].value;}"
	>
		<option value=""><?php echo @_MD_MAINFORUMOPT; ?>
</option>
		<option value="<?php echo $this->_tpl_vars['mark_read']; ?>
"><?php echo @_MD_MARK_ALL_FORUMS; ?>
&nbsp;<?php echo @_MD_MARK_READ; ?>
</option>
		<option value="<?php echo $this->_tpl_vars['mark_unread']; ?>
"><?php echo @_MD_MARK_ALL_FORUMS; ?>
&nbsp;<?php echo @_MD_MARK_UNREAD; ?>
</option>
		<option value="">--------</option>
		<option value="<?php echo $this->_tpl_vars['post_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_ALLPOSTS; ?>
</option>
		<option value="<?php echo $this->_tpl_vars['newpost_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_NEWPOSTS; ?>
</option>
		<option value="<?php echo $this->_tpl_vars['all_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_ALL; ?>
</option>
		<option value="<?php echo $this->_tpl_vars['digest_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_DIGEST; ?>
</option>
		<option value="<?php echo $this->_tpl_vars['unreplied_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_UNREPLIED; ?>
</option>
		<option value="<?php echo $this->_tpl_vars['unread_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_UNREAD; ?>
</option>
		<option value="">--------</option>
		<?php $_from = $this->_tpl_vars['menumode_other']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['menu']):
?>
		<option value="<?php echo $this->_tpl_vars['menu']['link']; ?>
"><?php echo $this->_tpl_vars['menu']['title']; ?>
</option>
		<?php endforeach; endif; unset($_from); ?>
		<?php if ($this->_tpl_vars['forum_index_cpanel']): ?>
		<option value="">--------</option>
		<option value="<?php echo $this->_tpl_vars['forum_index_cpanel']['link']; ?>
"><?php echo $this->_tpl_vars['forum_index_cpanel']['name']; ?>
</option>
		<?php endif; ?>
	</select>

<?php elseif ($this->_tpl_vars['menumode'] == 1): ?>
	<div id="mainoption" class="menu">
	<table><tr><td>
		<a class="item" href="<?php echo $this->_tpl_vars['mark_read']; ?>
"><?php echo @_MD_MARK_ALL_FORUMS; ?>
&nbsp;<?php echo @_MD_MARK_READ; ?>
</a>
		<a class="item" href="<?php echo $this->_tpl_vars['mark_unread']; ?>
"><?php echo @_MD_MARK_ALL_FORUMS; ?>
&nbsp;<?php echo @_MD_MARK_UNREAD; ?>
</a>
		<div class="separator"></div>
		<a class="item" href="<?php echo $this->_tpl_vars['post_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_ALLPOSTS; ?>
</a>
		<a class="item" href="<?php echo $this->_tpl_vars['newpost_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_NEWPOSTS; ?>
</a>
		<a class="item" href="<?php echo $this->_tpl_vars['all_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_ALL; ?>
</a>
		<a class="item" href="<?php echo $this->_tpl_vars['digest_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_DIGEST; ?>
</a>
		<a class="item" href="<?php echo $this->_tpl_vars['unreplied_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_UNREPLIED; ?>
</a>
		<a class="item" href="<?php echo $this->_tpl_vars['unread_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_UNREAD; ?>
</a>
		<div class="separator"></div>
		<?php $_from = $this->_tpl_vars['menumode_other']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['menu']):
?>
		<a class="item" href="<?php echo $this->_tpl_vars['menu']['link']; ?>
"><?php echo $this->_tpl_vars['menu']['title']; ?>
</a>
		<?php endforeach; endif; unset($_from); ?>
		<?php if ($this->_tpl_vars['forum_index_cpanel']): ?>
		<div class="separator"></div>
		<a class="item" href="<?php echo $this->_tpl_vars['forum_index_cpanel']['link']; ?>
"><?php echo $this->_tpl_vars['forum_index_cpanel']['name']; ?>
</a>
		<?php endif; ?>
	</td></tr></table>
	</div>
	<script type="text/javascript">document.getElementById("mainoption").onmouseout = closeMenu;</script>
	<div class="menubar"><a href="" onclick="openMenu(event, 'mainoption');return false;"><?php echo @_MD_MAINFORUMOPT; ?>
</a></div>

<?php elseif ($this->_tpl_vars['menumode'] == 2): ?>

	<div class="menu">
		<ul>
			<li>
				<div class="item"><strong><?php echo @_MD_MAINFORUMOPT; ?>
</strong></div>
				<ul>
				<li><table><tr><td>
					<div class="item"><a href="<?php echo $this->_tpl_vars['mark_read']; ?>
"><?php echo @_MD_MARK_ALL_FORUMS; ?>
&nbsp;<?php echo @_MD_MARK_READ; ?>
</a></div>
					<div class="item"><a href="<?php echo $this->_tpl_vars['mark_unread']; ?>
"><?php echo @_MD_MARK_ALL_FORUMS; ?>
&nbsp;<?php echo @_MD_MARK_UNREAD; ?>
</a></div>
					<div class="separator"></div>
					<div class="item"><a href="<?php echo $this->_tpl_vars['post_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_ALLPOSTS; ?>
</a></div>
					<div class="item"><a href="<?php echo $this->_tpl_vars['newpost_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_NEWPOSTS; ?>
</a></div>
					<div class="item"><a href="<?php echo $this->_tpl_vars['all_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_ALL; ?>
</a></div>
					<div class="item"><a href="<?php echo $this->_tpl_vars['digest_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_DIGEST; ?>
</a></div>
					<div class="item"><a href="<?php echo $this->_tpl_vars['unreplied_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_UNREPLIED; ?>
</a></div>
					<div class="item"><a href="<?php echo $this->_tpl_vars['unread_link']; ?>
"><?php echo @_MD_VIEW; ?>
&nbsp;<?php echo @_MD_UNREAD; ?>
</a></div>
					<div class="separator"></div>
					<?php $_from = $this->_tpl_vars['menumode_other']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['menu']):
?>
					<div class="item"><a href="<?php echo $this->_tpl_vars['menu']['link']; ?>
"><?php echo $this->_tpl_vars['menu']['title']; ?>
</a></div>
					<?php endforeach; endif; unset($_from); ?>
					<?php if ($this->_tpl_vars['forum_index_cpanel']): ?>
					<div class="separator"></div>
					<div class="item"><a href="<?php echo $this->_tpl_vars['forum_index_cpanel']['link']; ?>
"><?php echo $this->_tpl_vars['forum_index_cpanel']['name']; ?>
</a></div>
					<?php endif; ?>
				</td></tr></table></li>
				</ul>
			</li>
		</ul>
	</div>
<?php endif; ?>
</div>
<div class="clear"></div>
<br /><br />

<!-- start forum categories -->
<?php $_from = $this->_tpl_vars['categories']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['category']):
?>
<table class="index_category" cellspacing="0" width="100%">
    <tr class="head">
		<td width="3%" valign="middle" align="center"><img onclick="ToggleBlock2('cat_<?php echo $this->_tpl_vars['category']['cat_id']; ?>
', this)" src="<?php echo $this->_tpl_vars['category']['cat_display_icon']; ?>
" alt="" /></td>
		<?php if ($this->_tpl_vars['category']['cat_image']): ?>
		<td width="8%"><img src="<?php echo $this->_tpl_vars['category']['cat_image']; ?>
" alt="<?php echo $this->_tpl_vars['category']['cat_title']; ?>
" /></td>
		<?php endif; ?>
		<td align="left">
			<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/index.php?cat=<?php echo $this->_tpl_vars['category']['cat_id']; ?>
"><?php echo $this->_tpl_vars['category']['cat_title']; ?>
</a>
			<?php if ($this->_tpl_vars['category']['cat_description']): ?><p class="desc"><?php echo $this->_tpl_vars['category']['cat_description']; ?>
</p><?php endif; ?>
		</td>
		<?php if ($this->_tpl_vars['category']['cat_sponsor']): ?>
		<td width="15%" nowrap="nowrap" align="right">
		<p class="desc"><a href="<?php echo $this->_tpl_vars['category']['cat_sponsor']['link']; ?>
" title="<?php echo $this->_tpl_vars['category']['cat_sponsor']['title']; ?>
" target="_blank"><?php echo $this->_tpl_vars['category']['cat_sponsor']['title']; ?>
</a></p>
		</td>
		<?php endif; ?>
    </tr>
</table>

<div id="cat_<?php echo $this->_tpl_vars['category']['cat_id']; ?>
" style="display: <?php echo $this->_tpl_vars['category']['cat_display']; ?>
">
<table cellspacing="1" width="100%">
<?php if ($this->_tpl_vars['category']['forums']): ?>
    <tr class="head" align="center">
		<td width="5%">&nbsp;</td>
		<?php if ($this->_tpl_vars['subforum_display'] == 'expand'): ?>
		<td colspan="2" width="57%" nowrap="nowrap" align="left"><?php echo @_MD_FORUM; ?>
</td>
		<?php else: ?>
		<td width="57%" nowrap="nowrap" align="left"><?php echo @_MD_FORUM; ?>
</td>
		<?php endif; ?>
		<td width="9%" nowrap="nowrap"><?php echo @_MD_TOPICS; ?>
</td>
		<td width="9%" nowrap="nowrap"><?php echo @_MD_POSTS; ?>
</td>
		<td width="20%" nowrap="nowrap"><?php echo @_MD_LASTPOST; ?>
</td>
    </tr>
<?php endif; ?>

<!-- start forums -->

<?php if ($this->_tpl_vars['subforum_display'] == 'expand'): ?>

<?php $_from = $this->_tpl_vars['category']['forums']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['forum']):
?>
    <tr>
      <td class="even" align="center" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_folder']; ?>
</td>
      <td colspan="2" class="odd">
		<div id="index_forum">
	      	<span class="item"><a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/viewforum.php?forum=<?php echo $this->_tpl_vars['forum']['forum_id']; ?>
"><?php echo $this->_tpl_vars['forum']['forum_name']; ?>
</a>
	      	<?php if ($this->_tpl_vars['rss_enable']): ?>
			(<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/rss.php?f=<?php echo $this->_tpl_vars['forum']['forum_id']; ?>
" target="_blank" title="RSS feed">RSS</a>)
			<?php endif; ?>
	      	<br /><?php echo $this->_tpl_vars['forum']['forum_desc']; ?>

	      	</span>
			<?php if ($this->_tpl_vars['forum']['forum_moderators']): ?>
			<span class="extra">
        	<?php echo @_MD_MODERATOR; ?>
: <?php echo $this->_tpl_vars['forum']['forum_moderators']; ?>

        	</span>
        	<?php endif; ?>
        </div>
      </td>
      <td class="even" align="center" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_topics']; ?>
 </td>
      <td class="odd" align="center" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_posts']; ?>
 </td>
      <td class="even" align="right" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_lastpost_time']; ?>
 <br />
		<?php echo $this->_tpl_vars['forum']['forum_lastpost_icon']; ?>
 <br />
		<?php echo $this->_tpl_vars['forum']['forum_lastpost_user']; ?>

	  </td>
    </tr>
<?php if ($this->_tpl_vars['forum']['subforum']): ?>
    <tr class="head" >
      <td width="5%">&nbsp;</td>
      <td width="5%" align="center"><?php echo $this->_tpl_vars['img_subforum']; ?>
&nbsp;</td>
      <td colspan="4" nowrap="nowrap" align="left"><?php echo @_MD_SUBFORUMS; ?>
</td>
    </tr>
<?php $_from = $this->_tpl_vars['forum']['subforum']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['subforum']):
?>
    <tr>
      <td class="odd" width="5%">&nbsp;</td>
      <td class="even" align="center" valign="middle" width="5%"><?php echo $this->_tpl_vars['subforum']['forum_folder']; ?>
</td>
      <td width="52%" class="odd">
		<div id="index_forum">
	      	<span class="item"><a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/viewforum.php?forum=<?php echo $this->_tpl_vars['subforum']['forum_id']; ?>
"><strong><?php echo $this->_tpl_vars['subforum']['forum_name']; ?>
</strong></a>
	      	<?php if ($this->_tpl_vars['rss_enable']): ?>
			(<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/rss.php?f=<?php echo $this->_tpl_vars['subforum']['forum_id']; ?>
" target="_blank" title="RSS feed">RSS</a>)
			<?php endif; ?>
	      	<br /><?php echo $this->_tpl_vars['subforum']['forum_desc']; ?>

	      	</span>
			<?php if ($this->_tpl_vars['subforum']['forum_moderators']): ?>
			<span class="extra">
        	<?php echo @_MD_MODERATOR; ?>
: <?php echo $this->_tpl_vars['subforum']['forum_moderators']; ?>

        	</span>
        	<?php endif; ?>
        </div>
	  </td>
      <td class="even" width="9%" align="center" valign="middle"><?php echo $this->_tpl_vars['subforum']['forum_topics']; ?>
 </td>
      <td class="odd" width="9%" align="center" valign="middle"><?php echo $this->_tpl_vars['subforum']['forum_posts']; ?>
 </td>
      <td class="even" width="20%" align="right" valign="middle"><?php echo $this->_tpl_vars['subforum']['forum_lastpost_time']; ?>
 <br />
		<?php echo $this->_tpl_vars['subforum']['forum_lastpost_icon']; ?>
 <br />
		<?php echo $this->_tpl_vars['subforum']['forum_lastpost_user']; ?>

	  </td>
   </tr>
<?php endforeach; endif; unset($_from); ?>
<?php endif; ?>
<?php endforeach; endif; unset($_from); ?>

<?php elseif ($this->_tpl_vars['subforum_display'] == 'collapse'): ?>

<?php $_from = $this->_tpl_vars['category']['forums']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['forum']):
?>
	<tr>
		<?php if ($this->_tpl_vars['forum']['subforum']): ?>
      	<td class="even" rowspan="2" align="center" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_folder']; ?>
</td>
		<?php else: ?>
      	<td class="even" align="center" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_folder']; ?>
</td>
		<?php endif; ?>
      	<td class="odd">
		<div id="index_forum">
	      	<span class="item"><a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/viewforum.php?forum=<?php echo $this->_tpl_vars['forum']['forum_id']; ?>
"><?php echo $this->_tpl_vars['forum']['forum_name']; ?>
</a>
	      	<?php if ($this->_tpl_vars['rss_enable']): ?>
			(<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/rss.php?f=<?php echo $this->_tpl_vars['forum']['forum_id']; ?>
" target="_blank" title="RSS feed">RSS</a>)
			<?php endif; ?>
	      	<br /><?php echo $this->_tpl_vars['forum']['forum_desc']; ?>

	      	</span>
			<?php if ($this->_tpl_vars['forum']['forum_moderators']): ?>
			<span class="extra">
        	<?php echo @_MD_MODERATOR; ?>
: <?php echo $this->_tpl_vars['forum']['forum_moderators']; ?>

        	</span>
        	<?php endif; ?>
        </div>
        </td>
      	<td class="even" align="center" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_topics']; ?>
 </td>
      	<td class="odd" align="center" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_posts']; ?>
 </td>
      	<td class="even" align="right" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_lastpost_time']; ?>
 <br />
			<?php echo $this->_tpl_vars['forum']['forum_lastpost_icon']; ?>
 <br />
			<?php echo $this->_tpl_vars['forum']['forum_lastpost_user']; ?>
  </td>
    </tr>
	<?php if ($this->_tpl_vars['forum']['subforum']): ?>
    <tr>
     	<td class="odd" colspan="4" align="left"><?php echo @_MD_SUBFORUMS; ?>
&nbsp;<?php echo $this->_tpl_vars['img_subforum']; ?>
&nbsp;
			<?php $_from = $this->_tpl_vars['forum']['subforum']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['subforum']):
?>
			&nbsp;[<a href="viewforum.php?forum=<?php echo $this->_tpl_vars['subforum']['forum_id']; ?>
"><?php echo $this->_tpl_vars['subforum']['forum_name']; ?>
</a>]
			<?php endforeach; endif; unset($_from); ?>
		</td>
	</tr>
	<?php endif; ?>
<?php endforeach; endif; unset($_from); ?>

<?php else: ?>

<?php $_from = $this->_tpl_vars['category']['forums']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['forum']):
?>
	<tr>
      	<td class="even" align="center" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_folder']; ?>
</td>
      	<td class="odd">
		<div id="index_forum">
	      	<span class="item"><a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/viewforum.php?forum=<?php echo $this->_tpl_vars['forum']['forum_id']; ?>
"><?php echo $this->_tpl_vars['forum']['forum_name']; ?>
</a>
	      	<?php if ($this->_tpl_vars['rss_enable']): ?>
			(<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/rss.php?f=<?php echo $this->_tpl_vars['forum']['forum_id']; ?>
" target="_blank" title="RSS feed">RSS</a>)
			<?php endif; ?>
	      	<br /><?php echo $this->_tpl_vars['forum']['forum_desc']; ?>

	      	</span>
			<?php if ($this->_tpl_vars['forum']['forum_moderators']): ?>
			<span class="extra">
        	<?php echo @_MD_MODERATOR; ?>
: <?php echo $this->_tpl_vars['forum']['forum_moderators']; ?>

        	</span>
        	<?php endif; ?>
        </div>
        </td>
      	<td class="even" align="center" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_topics']; ?>
 </td>
      	<td class="odd" align="center" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_posts']; ?>
 </td>
      	<td class="even" align="right" valign="middle"><?php echo $this->_tpl_vars['forum']['forum_lastpost_time']; ?>
 <br />
			<?php echo $this->_tpl_vars['forum']['forum_lastpost_icon']; ?>
 <br />
			<?php echo $this->_tpl_vars['forum']['forum_lastpost_user']; ?>

		</td>
    </tr>
<?php endforeach; endif; unset($_from); ?>

<?php endif; ?>
  <!-- end forums -->
</table>
</div>
<?php endforeach; endif; unset($_from); ?>
<!-- end forum categories -->

<br />
<div>
<div style="float: left; text-align: left;">
	<?php echo $this->_tpl_vars['img_hotfolder']; ?>
 = <?php echo @_MD_NEWPOSTS; ?>
<br />
	<?php echo $this->_tpl_vars['img_folder']; ?>
 = <?php echo @_MD_NONEWPOSTS; ?>
<br />
	<?php echo $this->_tpl_vars['img_locked_newposts']; ?>
 = <?php echo @_MD_INACTIVEFORUM_NEWPOSTS; ?>
<br />
	<?php echo $this->_tpl_vars['img_locked_nonewposts']; ?>
 = <?php echo @_MD_INACTIVEFORUM_NONEWPOSTS; ?>

</div>
<div style="float: right; text-align: right;">
	<form action="search.php" method="post" name="search" id="search">
        <input name="term" id="term" type="text" size="20" />
        <input type="hidden" name="forum" id="forum" value="all" />
        <input type="hidden" name="sortby" id="sortby" value="p.post_time desc" />
        <input type="hidden" name="searchin" id="searchin" value="both" />
        <input type="submit" name="submit" id="submit" value="<?php echo @_MD_SEARCH; ?>
" />
        <br />
        [ <a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/search.php"><?php echo @_MD_ADVSEARCH; ?>
</a> ]
	</form>
</div>
</div>
<div class="clear"></div>

<br style="clear: both;" />
<div style="float:right;text-align:right;padding-top: 5px;">
	<?php if ($this->_tpl_vars['viewer_level'] > 1): ?>
		<?php if ($this->_tpl_vars['mode'] > 0): ?>
		<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/index.php?mode=0&amp;cat=<?php echo $this->_tpl_vars['viewcat']; ?>
" target="_self" title="<?php echo @_MD_TYPE_VIEW; ?>
"><?php echo @_MD_TYPE_VIEW; ?>
</a> 
		<?php else: ?>
		<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/index.php?mode=1&amp;cat=<?php echo $this->_tpl_vars['viewcat']; ?>
" target="_self" title="<?php echo @_MD_TYPE_ADMIN; ?>
"><?php echo @_MD_TYPE_ADMIN; ?>
</a>
		<?php endif; ?> 
	<?php endif; ?>
	<?php if ($this->_tpl_vars['rss_button']): ?>
	<a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/rss.php?c=<?php echo $this->_tpl_vars['viewcat']; ?>
" target="_blank" title="RSS FEED"><?php echo $this->_tpl_vars['rss_button']; ?>
</a>
	<br />
	<?php endif; ?>
	<a href="http://xoopsforge.com" target="_blank" title="Powered by CBB v<?php echo $this->_tpl_vars['version']; ?>
"><img src="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/<?php echo $this->_tpl_vars['xoops_dirname']; ?>
/images/cbb.png" alt="Powered by CBB v<?php echo $this->_tpl_vars['version']; ?>
" title="Powered by CBB v<?php echo $this->_tpl_vars['version']; ?>
" /></a>
</div>
<div class="clear"></div>

<br />
<br />
<?php if ($this->_tpl_vars['online']): ?><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:newbb_online.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><?php endif; ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'db:system_notification_select.html', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!-- end module contents -->