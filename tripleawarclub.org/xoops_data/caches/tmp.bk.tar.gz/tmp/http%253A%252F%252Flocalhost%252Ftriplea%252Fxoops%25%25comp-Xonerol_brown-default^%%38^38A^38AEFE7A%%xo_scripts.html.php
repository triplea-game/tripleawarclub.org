<?php /* Smarty version 2.6.26, created on 2010-05-13 08:45:45
         compiled from /var/www/triplea/xoops/modules/system/class/gui/oxygen/xotpl/xo_scripts.html */ ?>
<!-- Include files javascripts -->
<script type="text/javascript" src="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/js/styleswitch.js'; ?>"></script>
<script type="text/javascript" src="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/js/accordion.js'; ?>"></script>
<script type="text/javascript" src="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/js/formenu.js'; ?>"></script>
<script type="text/javascript" src="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/js/menu.js'; ?>"></script>
<script type="text/javascript" src="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/js/tooltip.js'; ?>"></script>

<!-- include style sheets Css of Scripts -->
<link rel="stylesheet" type="text/css" media="screen" title="dark" href="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/css/dark.css'; ?>" />
<link rel="stylesheet" type="text/css" media="screen" title="silver" href="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/css/silver.css'; ?>" />
<link rel="stylesheet" type="text/css" media="screen" title="orange" href="<?php 
echo 'http://localhost/triplea/xoops/modules/system/class/gui/oxygen/css/orange.css'; ?>" />