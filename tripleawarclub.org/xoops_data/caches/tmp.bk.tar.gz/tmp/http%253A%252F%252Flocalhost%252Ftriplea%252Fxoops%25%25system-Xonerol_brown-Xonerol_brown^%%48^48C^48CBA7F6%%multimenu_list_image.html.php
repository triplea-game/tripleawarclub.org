<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:list/multimenu_list_image.html */ ?>
<div class="head"><?php echo $this->_tpl_vars['other']; ?>
 <?php echo $this->_tpl_vars['item']; ?>
</div>
<div class="itemFoot">
<ul><?php $_from = $this->_tpl_vars['items_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
    <li style="list-style: none; display:inline; background-color:White; border:1px <?php if ($this->_tpl_vars['item']['id'] != $this->_tpl_vars['id']): ?>outset<?php else: ?>inset<?php endif; ?> grey; margin:0px; padding:5px;">
          <?php if ($this->_tpl_vars['item']['id'] != $this->_tpl_vars['id']): ?> <a href="<?php echo $this->_tpl_vars['item']['urw']; ?>
" title="<?php echo $this->_tpl_vars['item']['title']; ?>
 "> <?php endif; ?>
          <?php if ($this->_tpl_vars['item']['image']): ?>        <img src="<?php echo $this->_tpl_vars['item']['image']; ?>
" alt="<?php echo $this->_tpl_vars['item']['title']; ?>
" /> <?php else: ?> <?php echo $this->_tpl_vars['item']['title']; ?>
 <?php endif; ?>
          <?php if ($this->_tpl_vars['item']['id'] != $this->_tpl_vars['id']): ?> </a> <?php endif; ?>
        </li>
   <?php endforeach; endif; unset($_from); ?>
</ul>
</div>