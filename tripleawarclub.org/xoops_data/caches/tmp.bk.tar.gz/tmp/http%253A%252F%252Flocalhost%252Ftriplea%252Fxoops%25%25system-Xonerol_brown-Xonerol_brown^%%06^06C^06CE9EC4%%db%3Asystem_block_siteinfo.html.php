<?php /* Smarty version 2.6.26, created on 2010-05-13 10:50:19
         compiled from db:system_block_siteinfo.html */ ?>
<table class="outer" cellspacing="0">

  <?php if ($this->_tpl_vars['block']['showgroups'] == true): ?>

  <!-- start group loop -->
  <?php $_from = $this->_tpl_vars['block']['groups']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['group']):
?>
  <tr>
    <th colspan="2"><?php echo $this->_tpl_vars['group']['name']; ?>
</th>
  </tr>

  <!-- start group member loop -->
  <?php $_from = $this->_tpl_vars['group']['users']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['user']):
?>
  <tr>
    <td class="even" valign="middle" align="center">
        <img src="<?php echo $this->_tpl_vars['user']['avatar']; ?>
" alt="<?php echo $this->_tpl_vars['user']['name']; ?>
" width="32" /><br />
        <a href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/userinfo.php?uid=<?php echo $this->_tpl_vars['user']['id']; ?>
" title="<?php echo $this->_tpl_vars['user']['name']; ?>
"><?php echo $this->_tpl_vars['user']['name']; ?>
</a>
    </td>
    <td class="odd" width="20%" align="right" valign="middle">
        <?php echo $this->_tpl_vars['user']['msglink']; ?>

    </td>
  </tr>
  <?php endforeach; endif; unset($_from); ?>
  <!-- end group member loop -->

  <?php endforeach; endif; unset($_from); ?>
  <!-- end group loop -->
  <?php endif; ?>
</table>

<br />

<div style="margin: 3px; text-align:center;">
  <img src="<?php echo $this->_tpl_vars['block']['logourl']; ?>
" alt="" border="0" /><br /><?php echo $this->_tpl_vars['block']['recommendlink']; ?>

</div>