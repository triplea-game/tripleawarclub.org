<?php /* Smarty version 2.6.26, created on 2010-05-13 10:55:21
         compiled from db:system_block_dummy.html */ ?>
<?php echo $this->_tpl_vars['block']['content']; ?>