<?php /* Smarty version 2.6.26, created on 2010-07-06 03:43:33
         compiled from /var/www/vhosts/tripleawarclub.org/public_html/modules/system/class/gui/oxygen/xotpl/xo_navbar.html */ ?>
<div id="logoHead">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td>
                <a id="main_logo" class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/admin.php'; ?>" title="<?php echo @_MD_OXYGEN_ADMINISTRATION; ?>
"></a>
            </td>
            <td id="headnav" class="other">
                <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/'; ?>" title="<?php echo @_YOURHOME; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/img/home.png'; ?>" alt="<?php echo @_YOURHOME; ?>
" /></a>
                <a class="tooltip" href="<?php echo 'http://www.tripleawarclub.org/user.php?op=logout'; ?>" title="<?php echo @_LOGOUT; ?>
"><img src="<?php 
echo 'http://www.tripleawarclub.org/modules/system/class/gui/oxygen/img/logout.png'; ?>" alt="<?php echo @_LOGOUT; ?>
" /></a>
            </td>
        </tr>
    </table>
</div>