<?php /* Smarty version 2.6.26, created on 2010-05-14 12:55:08
         compiled from Xonerol_brown_clean/xotpl/xometas.html */ ?>
<title><?php if ($this->_tpl_vars['xoops_pagetitle'] != ''): ?><?php echo $this->_tpl_vars['xoops_pagetitle']; ?>
 : <?php endif; ?><?php echo $this->_tpl_vars['xoops_sitename']; ?>
</title>

<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->_tpl_vars['xoops_charset']; ?>
" />
<meta name="robots" content="<?php echo $this->_tpl_vars['xoops_meta_robots']; ?>
" />
<meta name="keywords" content="<?php echo $this->_tpl_vars['xoops_meta_keywords']; ?>
" />
<meta name="description" content="<?php echo $this->_tpl_vars['xoops_meta_description']; ?>
" />
<meta name="rating" content="<?php echo $this->_tpl_vars['xoops_meta_rating']; ?>
" />
<meta name="author" content="CB"/>
<meta name="copyright" content="<?php echo $this->_tpl_vars['xoops_meta_copyright']; ?>
" />
<meta name="generator" content="Bluefish 1.0.7"/>
<?php if ($this->_tpl_vars['url']): ?>
	<meta http-equiv="Refresh" content="<?php echo $this->_tpl_vars['time']; ?>
; url=<?php echo $this->_tpl_vars['url']; ?>
" />
<?php endif; ?>

<!-- include xoops.js and others via header.php 
<?php echo $this->_tpl_vars['xoops_module_header']; ?>
-->

  <!-- Blueprint Grid Framework CSS -->
  <link rel="stylesheet" href="<?php 
echo 'http://localhost/triplea/xoops/themes/Xonerol_brown_clean/css/blueprint/screen.css'; ?>" type="text/css" media="screen, projection" />
  <link rel="stylesheet" href="<?php 
echo 'http://localhost/triplea/xoops/themes/Xonerol_brown_clean/css/blueprint/print.css'; ?>" type="text/css" media="print" />
  <!--[if lt IE 8]><link rel="stylesheet" href="<?php 
echo 'http://localhost/triplea/xoops/themes/Xonerol_brown_clean/css/blueprint/ie.css'; ?>" type="text/css" media="screen, projection" /><![endif]-->
  
  <!-- Plugin CSS -->
  <link rel="stylesheet" href="<?php 
echo 'http://localhost/triplea/xoops/themes/Xonerol_brown_clean/css/blueprint/plugins/tabs/screen.css'; ?>" type="text/css" media="screen" />

  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="<?php 
echo 'http://localhost/triplea/xoops/themes/Xonerol_brown_clean/css/homepage.css'; ?>" type="text/css" media="screen" />

  <!-- Sliding login -->
  <link rel="stylesheet" href="<?php 
echo 'http://localhost/triplea/xoops/themes/Xonerol_brown_clean/css/slide.css'; ?>" type="text/css" media="screen" />

<!-- Xoops style sheet -->
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo 'http://localhost/triplea/xoops/xoops.css'; ?>" />

<!-- Theme style sheets -->
<link rel="stylesheet" type="text/css" media="screen,projection,print" href="<?php 
echo 'http://localhost/triplea/xoops/css/layout-soup.css'; ?>" /><!-- canvas theme style sheet -->
<link rel="stylesheet" type="text/css" media="screen" title="Color" href="<?php 
echo 'http://localhost/triplea/xoops/css/style.css'; ?>" />
<link rel="stylesheet" type="text/css" media="print" href="<?php 
echo 'http://localhost/triplea/xoops/css/print.css'; ?>" />  <!-- print style sheet experimental -->
<!--<link rel="stylesheet" type="text/css" media="aural" href="<?php 
echo 'http://localhost/triplea/xoops/aural.css'; ?>" />-->  <!-- audio style sheet -->

