<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:include/multimenu_select.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'stristr', 'db:include/multimenu_select.html', 19, false),array('modifier', 'replace', 'db:include/multimenu_select.html', 42, false),)), $this); ?>
<?php if ($this->_tpl_vars['ii'] < 12): ?>
     <form action="">
     <select size="1" 
             name="multimenu_<?php echo $this->_tpl_vars['menu']; ?>
"
<?php else: ?>
     <form action="" method="post">
     <select size="5" 
             name="multimenu_<?php echo $this->_tpl_vars['menu']; ?>
"
<?php endif; ?>      onchange="location=this.options[this.selectedIndex].value"
             style="width:160px;"
     >

<option value="" selected="selected"></option>

<?php $_from = $this->_tpl_vars['data_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>

<?php if (! $this->_tpl_vars['item']['link']): ?>

<?php if (((is_array($_tmp=$this->_tpl_vars['item']['title'])) ? $this->_run_mod_handler('stristr', true, $_tmp, "<hr") : stristr($_tmp, "<hr"))): ?>
<!-- New form -->
<?php if ($this->_tpl_vars['optgroup']): ?></optgroup><?php endif; ?>
</select>
</form>

                    <?php if ($this->_tpl_vars['item']['link']): ?>

                      <a   href="<?php echo $this->_tpl_vars['item']['link']; ?>
"
                           <?php if ($this->_tpl_vars['item']['popgen']): ?><?php echo $this->_tpl_vars['item']['popgen']; ?>
<?php else: ?>
                           <?php echo $this->_tpl_vars['item']['target']; ?>

                           <?php endif; ?>
                           <?php if ($this->_tpl_vars['item']['alt_title']): ?>title="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?>
                           <?php if ($this->_tpl_vars['item']['css']): ?>style="<?php echo $this->_tpl_vars['item']['css']; ?>
"<?php endif; ?>
                      >
                    <?php endif; ?>
                    <?php if ($this->_tpl_vars['item']['image']): ?>
                      <img src="<?php echo $this->_tpl_vars['item']['image']; ?>
"
                           <?php if ($this->_tpl_vars['item']['alt_title']): ?>alt="<?php echo $this->_tpl_vars['item']['alt_title']; ?>
"<?php endif; ?>
                           align="absmiddle"
                           <?php echo $this->_tpl_vars['image_width']; ?>
<?php echo $this->_tpl_vars['image_height']; ?>

                      />
                      <?php endif; ?>
                      <h3><?php echo ((is_array($_tmp=$this->_tpl_vars['item']['title'])) ? $this->_run_mod_handler('replace', true, $_tmp, "<hr />", "") : smarty_modifier_replace($_tmp, "<hr />", "")); ?>
</h3>
                      <?php if ($this->_tpl_vars['item']['link']): ?></a><?php endif; ?><?php if ($this->_tpl_vars['ii'] < 12): ?>
     <form action="">
     <select size="1" name="multimenu_<?php echo $this->_tpl_vars['menu']; ?>
"
<?php else: ?>
     <form action="" method="post">
     <select size="5" name="multimenu_<?php echo $this->_tpl_vars['menu']; ?>
"
<?php endif; ?>      onchange="location=this.options[this.selectedIndex].value"
             style="width:160px;"
     >

<option value="" selected="selected"></option>
<!-- End new form -->

<?php else: ?>
<?php if ($this->_tpl_vars['optgroup']): ?>
     </optgroup><?php endif; ?>
     <optgroup label="<?php echo $this->_tpl_vars['item']['title']; ?>
">
     <?php $this->assign('optgroup', 1); ?>
<?php endif; ?>
<?php else: ?>

<option value="<?php if ($this->_tpl_vars['item']['link']): ?><?php echo $this->_tpl_vars['item']['link']; ?>
<?php else: ?>#<?php endif; ?>">
<?php if ($this->_tpl_vars['item']['link_status'] == top): ?>
<?php elseif ($this->_tpl_vars['previous_status'] == top && $this->_tpl_vars['item']['link_status'] == sublink): ?>--
<?php elseif ($this->_tpl_vars['previous_status'] == link && $this->_tpl_vars['item']['link_status'] == sublink): ?>--
<?php elseif ($this->_tpl_vars['previous_status'] == sublink && $this->_tpl_vars['item']['link_status'] == sublink): ?>--
<?php elseif ($this->_tpl_vars['previous_status'] == sublink && $this->_tpl_vars['item']['link_status'] == link): ?>
<?php endif; ?><?php $this->assign('previous_status', $this->_tpl_vars['item']['link_status']); ?>

	<?php echo $this->_tpl_vars['item']['title']; ?>

	</option>

<?php endif; ?>
        <?php endforeach; endif; unset($_from); ?>
<?php if ($this->_tpl_vars['optgroup']): ?></optgroup><?php endif; ?>
</select>
</form>
<br />