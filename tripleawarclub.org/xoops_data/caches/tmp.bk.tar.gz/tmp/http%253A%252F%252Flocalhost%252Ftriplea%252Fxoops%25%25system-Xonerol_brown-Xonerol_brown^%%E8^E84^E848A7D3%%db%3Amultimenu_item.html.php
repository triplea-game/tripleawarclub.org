<?php /* Smarty version 2.6.26, created on 2010-05-20 12:47:50
         compiled from db:multimenu_item.html */ ?>
<!-- Start - Module:<?php echo $this->_tpl_vars['module']; ?>
 - Template:<?php echo $this->_tpl_vars['mode']; ?>
 -->

<?php if ($this->_tpl_vars['css_link']): ?>
<link rel="stylesheet" type="text/css" media="all" href="<?php echo $this->_tpl_vars['xoops_url']; ?>
<?php echo $this->_tpl_vars['css_link']; ?>
" />
<?php endif; ?>

<?php if ($this->_tpl_vars['css']): ?>
<style type="text/css">
<?php echo $this->_tpl_vars['css']; ?>

</style>
<?php endif; ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:multimenu_header.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['css']): ?><div id="multimenu_<?php echo $this->_tpl_vars['menu']; ?>
"><?php endif; ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:".($this->_tpl_vars['mode']), 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['css']): ?></div><?php endif; ?>

<p />
<?php if ($this->_tpl_vars['pagenav']): ?>
     <div style="padding-left:70%; width:60%; align:center;"><?php echo $this->_tpl_vars['pagenav']; ?>
</div>
<?php endif; ?>

<?php if ($this->_tpl_vars['item_list']): ?>
  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:".($this->_tpl_vars['item_list']), 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php endif; ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:multimenu_footer.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php if ($this->_tpl_vars['admin'] && $this->_tpl_vars['is_admin'] && $this->_tpl_vars['edit_mode']): ?>
<div align="center" class="head">
<p />
<?php echo $this->_tpl_vars['source_code']; ?>
 : (<?php echo $this->_tpl_vars['mode']; ?>
) <br />
     <textarea style="color:Grey;" cols="80" rows="25">
     <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "db:".($this->_tpl_vars['mode']), 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
     </textarea>
<p />
</div>
<?php endif; ?>