<?php /* Smarty version 2.6.26, created on 2010-05-13 10:50:19
         compiled from db:ams_block_topicnav.html */ ?>
<table cellspacing="0">
    <tr>
        <td id="mainmenu">
            <?php $_from = $this->_tpl_vars['block']['topics']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['topic']):
?>
                <a class="menuMain" href="<?php echo $this->_tpl_vars['xoops_url']; ?>
/modules/AMS/index.php?storytopic=<?php echo $this->_tpl_vars['topic']['id']; ?>
"><?php echo $this->_tpl_vars['topic']['title']; ?>
</a>
            <?php endforeach; endif; unset($_from); ?>
        </td>
    </tr>
</table>